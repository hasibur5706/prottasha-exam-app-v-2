# Prottasha Academy – Android app (live server)

Built against the real backend of prottashaacademy.com (routes/*.js). All data lives on the server;
nothing is stored on the phone (no localStorage, no backup, no cache). You log in each time.

Features: register/login (email + password, min 6), online exams (confirm, timer, auto-submit,
hidden-result handling, face check when required), OMR choice + question paper + sheet photo upload
(raw JPEG) + OMR result review, batches (free join, paid join with method/sender number/transaction id),
practice (random / per exam), adaptive exam, AI explanation (practice), leaderboard, performance,
history, face personal care (enroll by camera or photo, attendance, leave) and results.

Build: upload this folder (keep the hidden .github folder) to GitHub -> Actions -> Build APK.
Diagnostics: Profile -> "সংযোগ পরীক্ষা".
Face recognition loads face-api.js + models from cdn.jsdelivr.net at runtime (same as the website).
