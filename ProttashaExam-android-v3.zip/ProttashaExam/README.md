# Prottasha Academy – Android app (live server)

Native Android app with all pages, connected to https://prottashaacademy.com/api
(routes taken from the original APK: /auth/login, /auth/register, /public/home,
/online/exams, /online/exams/{id}/start|submit, /online/results/{id}, /exam/generate,
/exam/generate-adaptive, /exam/leaderboard, /exam/performance, /exam/practice-exams,
/omr/batches, /face/me).

## Build the APK with GitHub
1. Create a GitHub repo, upload ALL files of this folder (keep the hidden `.github` folder).
2. Actions tab -> "Build APK" -> Run workflow.
3. Download the `ProttashaExam-APK` artifact -> unzip -> `app-debug.apk`. Uninstall the old app first.

## Login
Use the same EMAIL + password as on the website (Register creates a real account on the server).

## If something does not load
Open the app -> Profile -> "সংযোগ পরীক্ষা" (connection check). It calls the main routes and shows
status codes + server replies. Send a screenshot of that screen to fix any mismatch quickly.

## Settings
`app/src/main/assets/app/config.js`
- `DEMO: true` switches to offline sample data.
- `ROUTES` lists every API path; routes with several paths are tried in order until one works.
- JSON field names are read tolerantly in `api.js` (mapQ / mapExam / mapResult / auth).
