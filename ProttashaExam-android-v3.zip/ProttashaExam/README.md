# Prottasha Academy – Android app (server-only data)

All data lives on https://prottashaacademy.com. Nothing is stored on the phone
(no localStorage, no backup, no cache). You log in each time you open the app.

Server-connected features: register/login, batches (list, join, paid join with transaction id,
approval status), exams (start, timer, submit), results + review (from /exam/performance and
/online/results), AI explanation, practice, adaptive exam, leaderboard, OMR (batch/exam list,
upload, status), face personal care (join with consent, attendance, history, leave).

Settings and every API route: `app/src/main/assets/app/config.js`
If a feature shows an error, open Profile -> "সংযোগ পরীক্ষা" and send a screenshot.
