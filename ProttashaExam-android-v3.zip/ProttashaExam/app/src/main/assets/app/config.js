/* Live server only. Every route used by the app is documented in api.js and matches the website's backend. */
window.PA_CONFIG = { BASE: 'https://prottashaacademy.com/api' };
