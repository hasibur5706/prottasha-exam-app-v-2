/* ====== SETTINGS ======
   DEMO=false -> live server (BASE). DEMO=true -> offline sample data.
   Routes below were taken from the original Prottasha APK. */
window.PA_CONFIG = {
  DEMO: false,
  BASE: 'https://prottashaacademy.com/api',
  ROUTES: {
    login:       ['POST', ['/auth/login']],
    register:    ['POST', ['/auth/register']],
    home:        ['GET',  ['/public/home']],
    exams:       ['GET',  ['/online/exams']],
    start:       ['POST', ['/online/exams/{id}/start']],
    submit:      ['POST', ['/online/exams/{id}/submit']],
    result:      ['GET',  ['/online/results/{id}']],
    review:      ['GET',  ['/online/results/{id}/review', '/online/results/{id}']],
    practice:    ['POST', ['/exam/generate']],
    practiceHist:['GET',  ['/exam/practice-exams']],
    adaptive:    ['POST', ['/exam/generate-adaptive']],
    leaderboard: ['GET',  ['/exam/leaderboard']],
    performance: ['GET',  ['/exam/performance']],
    join:        ['POST', ['/batches/{id}/join', '/public/batches/{id}/join', '/online/batches/{id}/join', '/student/batches/{id}/join', '/omr/batches/{id}/join']],
    explain:     ['POST', ['/exam/explain', '/ai/explain', '/online/explain']],
    omrBatches:  ['GET',  ['/omr/batches']],
    omrUpload:   ['POST', ['/omr/exams/{id}/submission', '/omr/exams/{id}/submit']],
    faceMe:      ['GET',  ['/face/me']],
    faceEnroll:  ['POST', ['/face/me']],
    attendance:  ['POST', ['/face/attendance', '/face/checkin', '/face/mark', '/attendance/mark', '/face/verify']]
  }
};
