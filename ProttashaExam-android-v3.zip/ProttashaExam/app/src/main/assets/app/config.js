/* ====== SETTINGS ======
   All data lives on the server. Nothing is stored on the phone.
   ROUTES: every API path used by the app. When several paths are listed they are tried in order
   (a 404/405 moves on to the next). Routes marked (APK) were found inside the original Prottasha APK. */
window.PA_CONFIG = {
  DEMO: false,
  BASE: 'https://prottashaacademy.com/api',
  ROUTES: {
    login:        ['POST', ['/auth/login']],                                   // (APK)
    register:     ['POST', ['/auth/register']],                                // (APK)
    home:         ['GET',  ['/public/home']],                                  // (APK)
    exams:        ['GET',  ['/online/exams']],                                 // (APK)
    start:        ['POST', ['/online/exams/{id}/start']],                      // (APK)
    submit:       ['POST', ['/online/exams/{id}/submit', '/exam/{id}/submit']],       // (APK)
    review:       ['GET',  ['/online/results/{id}/review']],
    resultsList:  ['GET',  ['/online/results', '/exam/results', '/online/my-results', '/exam/history']],
    practice:     ['POST', ['/exam/generate']],                                // (APK)
    practiceHist: ['GET',  ['/exam/practice-exams']],                          // (APK)
    adaptive:     ['POST', ['/exam/generate-adaptive']],                       // (APK)
    leaderboard:  ['GET',  ['/exam/leaderboard']],                             // (APK)
    performance:  ['GET',  ['/exam/performance']],                             // (APK)
    join:         ['POST', ['/omr/batches/{id}/join', '/batches/{id}/join', '/public/batches/{id}/join', '/online/batches/{id}/join', '/student/batches/{id}/join']],
    explain:      ['POST', ['/exam/explain', '/exam/ai-explain', '/exam/explanation', '/online/explain', '/ai/explain', '/exam/questions/{id}/explain', '/online/questions/{id}/explain']],
    omrBatches:   ['GET',  ['/omr/batches']],                                  // (APK)
    omrStatus:    ['GET',  ['/omr/exams/{id}/submission', '/omr/results/{id}']], // (APK)
    omrUpload:    ['POST', ['/omr/exams/{id}/submission', '/omr/exams/{id}/submit']],
    faceMe:       ['GET',  ['/face/me']],                                      // (APK)
    faceEnroll:   ['POST', ['/face/me']],
    faceLeave:    ['DELETE',['/face/me']],
    attendance:   ['POST', ['/face/attendance', '/face/checkin', '/face/mark', '/face/me/attendance', '/attendance/mark', '/face/verify']]
  }
};
