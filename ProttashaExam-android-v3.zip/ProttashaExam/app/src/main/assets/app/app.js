(()=>{
'use strict';
const API=window.PA_API,CFG=window.PA_CONFIG;
const $=s=>document.querySelector(s),app=$('#app'),layer=$('#layer');
const bn=s=>String(s).replace(/\d/g,d=>'০১২৩৪৫৬৭৮৯'[d]);
const esc=s=>String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const P={back:'<path d="M15 5l-7 7 7 7"/>',home:'<path d="M4 11l8-7 8 7v9H4z"/>',doc:'<path d="M5 4h14v16H5zM9 9h6M9 13h6"/>',chart:'<path d="M4 20V10M10 20V4M16 20v-8"/>',user:'<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0116 0"/>',bell:'<path d="M6 17V11a6 6 0 0112 0v6l2 2H4zM10 21h4"/>',book:'<path d="M12 6c-2-2-5-2-8-1v13c3-1 6-1 8 1 2-2 5-2 8-1V5c-3-1-6-1-8 1zM12 6v13"/>',omr:'<rect x="5" y="3" width="14" height="18" rx="3"/><path d="M9 8h6M9 12h6M9 16h4"/>',cup:'<path d="M8 21h8M12 17v4M7 4h10v5a5 5 0 01-10 0zM7 6H4v2a3 3 0 003 3M17 6h3v2a3 3 0 01-3 3"/>',team:'<circle cx="9" cy="8" r="3"/><path d="M3 20a6 6 0 0112 0M16 5a3 3 0 010 6M18 20a5 5 0 00-3-4.5"/>',face:'<path d="M4 8V5h3M17 4h3v4M20 16v3h-3M7 20H4v-3M9 10v1M15 10v1M9 15c1.5 1.5 4.5 1.5 6 0"/>',target:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/>',check:'<path d="M5 12l5 5 9-10"/>',x:'<path d="M6 6l12 12M18 6L6 18"/>',spark:'<path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8zM19 16l.8 2.2L22 19l-2.2.8L19 22l-.8-2.2L16 19l2.2-.8z"/>',img:'<rect x="3" y="4" width="18" height="16" rx="3"/><circle cx="9" cy="10" r="2"/><path d="M21 16l-5-5-8 9"/>',out:'<path d="M9 4H5v16h4M16 8l4 4-4 4M20 12H9"/>',help:'<circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 115 0c0 2-2.5 2-2.5 4M12 17v.5"/>',chev:'<path d="M9 5l7 7-7 7"/>',card:'<rect x="3" y="6" width="18" height="13" rx="3"/><path d="M3 11h18"/>',web:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3 3 3 15 0 18M12 3c-3 3-3 15 0 18"/>'};
const ic=(n,c='currentColor',s=22)=>`<svg width="${s}" height="${s}" viewBox="0 0 24 24" fill="none" stroke="${c}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${P[n]}</svg>`;
/* all data lives on the server; this object only holds what is on screen right now (memory) */
const S={user:null,token:null,attempts:[]};
const DB={exams:[],batches:[],board:[],perf:{done:0,need:0,ready:false,topics:[]},hist:[],pex:[],omr:[],face:{enrolled:false,status:null,photo:null,recent:[]}};
let cur='splash',hist=[],E=null,tmr=null,stream=null,faceRun=null,omrFile=null,cleanup=()=>{};
const dayKey=(d=new Date())=>d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0');
const tmS=m=>new Date(m).toLocaleTimeString('bn-BD',{hour:'2-digit',minute:'2-digit'});
const dtS=m=>new Date(m).toLocaleString('bn-BD',{dateStyle:'medium',timeStyle:'short'});
const fmt=s=>bn(String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0'));
function toast(m){const t=$('#toast');t.textContent=m;t.className='on';clearTimeout(toast.t);toast.t=setTimeout(()=>t.className='',3000)}
function sheet(h){layer.innerHTML=`<div class="mask"><div class="sheet">${h}</div></div>`}
const closeSheet=()=>{layer.innerHTML=''};
const top=(t,s='')=>`<div class="top u"><button class="ib" data-act="back" aria-label="পেছনে">${ic('back')}</button><div><b>${t}</b><small>${s}</small></div></div>`;
const nav=a=>`<nav class="nav">${[['home','হোম','home'],['exams','পরীক্ষা','doc'],['results','ফলাফল','chart'],['more','প্রোফাইল','user']].map(([k,l,i])=>`<a data-tab="${k}" class="${k===a?'on':''}">${ic(i,'currentColor',24)}<span>${l}</span></a>`).join('')}</nav>`;
const ti=(k,i,sz)=>`<span class="ti ${k}"${sz?` style="width:${sz}px;height:${sz}px"`:''}>${ic(i)}</span>`;
const bar=(p,c)=>`<div class="bar"><i style="width:${Math.max(0,Math.min(100,p))}%;background:${c}"></i></div>`;
const chip=(t,c)=>`<span class="chip c-${c}">${t}</span>`;
const logo=s=>`<img src="logo.png" alt="লোগো" width="${s}" height="${s}" style="display:block;object-fit:contain">`;
const user=()=>(S.user&&S.user.name)||'শিক্ষার্থী';
const ex=id=>DB.exams.find(e=>String(e.id)===String(id));
const STATE={open:['চালু','a'],in_progress:['চলছে','a'],upcoming:['আসন্ন','i'],done:['সম্পন্ন','g'],locked:['ব্যাচে যুক্ত হও','r'],closed:['বন্ধ','r'],expired:['সময় শেষ','r'],omr:['OMR-এ','i'],empty:['প্রশ্ন নেই','r']};
const stChip=e=>chip(STATE[e.state]?STATE[e.state][0]:esc(e.state),STATE[e.state]?STATE[e.state][1]:'i');
const canOnline=e=>(e.state==='open'||e.state==='in_progress')&&e.mode!=='omr';
const pctOf=a=>a.percent!==undefined&&a.percent!==null?Math.round(a.percent):(a.total?Math.round(a.correct*100/a.total):0);

/* ---------- router ---------- */
function go(r,rep){if(rep!==true&&rep!=='root'&&cur)hist.push(cur);if(rep==='root')hist=[];cur=r;draw()}
function replaceWith(r){hist=hist.filter(h=>!h.startsWith('face')&&!h.startsWith('omrup'));if(hist[hist.length-1]===r)hist.pop();cur=r;draw()}
function back(){if(cur==='exam'&&E){leaveExam();return true}if(!hist.length)return false;cur=hist.pop();draw();return true}
window.__back=()=>{if(layer.innerHTML){closeSheet();return true}return back()};
window.__authLost=m=>{S.token=null;S.user=null;E=null;toast(m||'আবার লগইন করো');go('login','root')};
function draw(){
  const [n,...a]=cur.split(':');
  if(n!=='exam'&&tmr){clearInterval(tmr);tmr=null}
  cleanup();cleanup=()=>{};
  const s=R[n](...a);
  app.className=s.noanim?'noanim':'';
  app.innerHTML=`<div class="screen ${s.dark?'dark':''} ${s.nonav?'nonav':''}"><i class="orb" style="top:-120px;right:-110px;width:280px;height:280px"></i>${s.html}</div>`;
  if(s.cleanup)cleanup=s.cleanup;
  if(s.after)s.after();
}
const R={};
/* ---------- auth ---------- */
R.splash=()=>({dark:1,nonav:1,html:`<div style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:16px;position:relative"><div style="width:120px;height:120px;border-radius:36px;background:#181B4A;border:1px solid #2A2E6B;display:flex;align-items:center;justify-content:center;animation:fl 4s infinite,pu 2s infinite">${logo(84)}</div><h1 class="u" style="margin:8px 0 0;font-size:34px;animation-delay:.3s">প্রত্যাশা একাডেমি</h1><div class="u" style="font:600 13px Sora,sans-serif;letter-spacing:.2em;color:#FFB020;animation-delay:.5s">PROTTASHA ACADEMY</div><p class="u mut" style="margin:0;font-size:16px;animation-delay:.7s">প্রস্তুতি হোক আত্মবিশ্বাসের</p><div style="position:absolute;bottom:70px;width:140px;height:5px;border-radius:5px;background:#2A2E6B;overflow:hidden"><i style="display:block;height:100%;background:#FFB020;animation:ld 2.2s both"></i></div></div>`,after(){const t=setTimeout(()=>{if(cur==='splash')go('login',true)},2300);cleanup=()=>clearTimeout(t)}});
const fld=(id,l,ph,t)=>`<label class="f">${l}<input class="in" id="${id}" placeholder="${ph}" type="${t}" autocomplete="off"></label>`;
R.login=()=>({dark:1,nonav:1,html:`<div class="row u" style="margin-top:34px;position:relative">${logo(44)}<b style="font-size:20px">প্রত্যাশা একাডেমি</b></div><div class="u"><h1 style="margin:0 0 4px;font-size:32px">স্বাগতম!</h1><div class="mut" style="font-size:16px">অ্যাকাউন্টে ঢুকে পরীক্ষা শুরু করো</div></div><div class="seg u"><button class="on">লগইন</button><button data-go="register" data-rep="1">রেজিস্টার</button></div><div class="u" style="display:flex;flex-direction:column;gap:14px">${fld('em','ইমেইল','you@example.com','email')}${fld('pw','পাসওয়ার্ড','••••••••','password')}</div><button class="btn b-a pulse u" data-act="login">লগইন করো</button>`});
R.register=()=>({dark:1,nonav:1,html:`<div class="row u" style="margin-top:34px;position:relative">${logo(44)}<b style="font-size:20px">প্রত্যাশা একাডেমি</b></div><div class="u"><h1 style="margin:0 0 4px;font-size:30px">নতুন অ্যাকাউন্ট</h1><div class="mut" style="font-size:15px">কয়েক সেকেন্ডেই রেজিস্টার করো</div></div><div class="seg u"><button data-go="login" data-rep="1">লগইন</button><button class="on">রেজিস্টার</button></div><div class="u" style="display:flex;flex-direction:column;gap:12px">${fld('nm','পূর্ণ নাম','তোমার নাম','text')}${fld('em','ইমেইল','you@example.com','email')}${fld('pw','পাসওয়ার্ড','কমপক্ষে ৬ অক্ষর','password')}</div><button class="btn b-a pulse u" data-act="register">রেজিস্টার করো</button>`});
/* ---------- home ---------- */
R.home=()=>{
  const live=DB.exams.find(canOnline),todo=DB.exams.filter(canOnline).length,done=DB.exams.filter(e=>e.state==='done').length,h=new Date().getHours(),g=h<12?'শুভ সকাল':h<17?'শুভ অপরাহ্ণ':'শুভ সন্ধ্যা';
  const tiles=[['exams','doc','i','পরীক্ষা'],['practice','book','g','প্র্যাকটিস'],['omr','omr','p','ওএমআর'],['results','chart','r','ফলাফল'],['board','cup','a','লিডারবোর্ড'],['batches','team','b','ব্যাচ'],['attend','face','k','অ্যাটেনডেন্স'],['adaptive','target','s','অ্যাডাপটিভ']];
  const up=DB.exams.filter(e=>e.state==='upcoming').slice(0,3),tp=DB.perf.topics.slice(0,6);
  return {html:`<div class="row u"><div style="width:48px;height:48px;border-radius:50%;background:#FFB020;color:#1A1300;font-weight:700;font-size:20px;display:flex;align-items:center;justify-content:center">${esc(user()[0])}</div><div class="grow1"><div class="mut" style="font-size:14px">${g}</div><b style="font-size:19px">${esc(user())}</b></div><button class="ib" data-act="bell" style="position:relative">${ic('bell')}${todo?`<i style="position:absolute;top:11px;right:12px;width:9px;height:9px;border-radius:50%;background:#FFB020;animation:bl 1.4s infinite"></i>`:''}</button></div>
${live?`<div class="hero u" style="animation-delay:.1s"><span class="chip live"><i style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#FFB020;margin-right:6px;animation:bl 1.2s infinite"></i>${live.state==='in_progress'?'চলছে':'লাইভ পরীক্ষা'}</span><b style="font-size:22px;line-height:1.25">${esc(live.title)}</b><span class="sub">${live.batch?esc(live.batch)+' · ':''}${live.n?bn(live.n)+' প্রশ্ন · ':''}${bn(live.time)} মিনিট</span>${live.endMs?`<span class="sub">শেষ: ${dtS(live.endMs)}</span>`:''}<button class="btn b-a pulse sm" style="width:auto;align-self:flex-start;padding:0 22px" data-go="instr:${live.id}">${live.state==='in_progress'?'চালিয়ে যাও':'পরীক্ষা শুরু করো'}</button></div>`:`<div class="hero u"><span class="chip live">এখন</span><b style="font-size:22px">কোনো পরীক্ষা চালু নেই</b><span class="sub">নতুন পরীক্ষা চালু হলে এখানে দেখা যাবে। ততক্ষণ প্র্যাকটিস করতে পারো।</span></div>`}
<div class="stats u" style="animation-delay:.15s">${[[todo,'দেওয়া যাবে'],[done,'সম্পন্ন'],[DB.batches.filter(b=>b.state==='active').length,'আমার ব্যাচ']].map(([v,l])=>`<div class="lstat"><b style="font-family:Sora">${bn(v)}</b><span>${l}</span></div>`).join('')}</div>
<div class="grid4">${tiles.map(([r,i,k,l],n)=>`<button class="tile t u" style="animation-delay:.${n+2}s" data-go="${r}"><span class="ti ${k}">${ic(i,'currentColor',26)}</span>${l}</button>`).join('')}</div>
${up.length?`<b style="font-size:19px">আসন্ন পরীক্ষা</b>${up.map(e=>`<div class="card row t" data-go="instr:${e.id}">${ti('i','doc')}<div class="grow1"><b style="font-size:16px">${esc(e.title)}</b><div class="mut">${e.startMs?dtS(e.startMs):''}</div></div>${stChip(e)}</div>`).join('')}`:''}
<div class="card"><b style="font-size:17px;display:block;margin-bottom:12px">পরীক্ষাভিত্তিক পারফরম্যান্স</b>${tp.length?tp.map(t=>`<div style="margin-bottom:12px"><div class="row" style="justify-content:space-between;font-size:14px;margin-bottom:6px"><span>${esc(t.n)}</span><b>${bn(t.p)}%</b></div>${bar(t.p,t.p<50?'#D9573B':t.p<70?'#C98A00':'#0E8F7A')}</div>`).join(''):'<div class="mut">ব্যাচের পরীক্ষা দিয়ে ফলাফল প্রকাশ হলে এখানে পারফরম্যান্স দেখা যাবে।</div>'}</div>${nav('home')}`}
};
/* ---------- exams ---------- */
R.exams=(f='all')=>{
  const L=DB.exams.filter(e=>f==='all'||(f==='do'&&canOnline(e))||(f==='up'&&e.state==='upcoming')||(f==='done'&&e.state==='done'));
  return {html:`${top('পরীক্ষা','তোমার ব্যাচের সব পরীক্ষা')}<div class="chips u">${[['all','সব'],['do','দেওয়া যাবে'],['up','আসন্ন'],['done','সম্পন্ন']].map(([k,l])=>`<button class="fc ${k===f?'on':''}" data-go="exams:${k}" data-rep="1">${l}</button>`).join('')}</div>${L.length?L.map((e,i)=>`<div class="card row t u" style="animation-delay:.${i%8}s" data-go="instr:${e.id}">${ti('i','doc')}<div class="grow1"><b style="font-size:16px">${esc(e.title)}</b><div class="mut">${e.batch?esc(e.batch)+' · ':''}${bn(e.n)} প্রশ্ন · ${bn(e.time)} মি.</div></div>${stChip(e)}</div>`).join(''):'<div class="empty">কোনো পরীক্ষা পাওয়া যায়নি</div>'}${nav('exams')}`}
};
R.instr=id=>{
  const e=ex(id);if(!e)return {nonav:1,html:top('পরীক্ষা')+'<div class="empty">পরীক্ষা পাওয়া যায়নি</div>'};
  const msg={locked:'এই পরীক্ষা তোমার ব্যাচের অন্তর্ভুক্ত নয়। আগে ব্যাচে যুক্ত হও।',upcoming:'পরীক্ষা শুরু হবে: '+(e.startMs?dtS(e.startMs):'শীঘ্রই'),closed:'এই পরীক্ষার সময়সীমা শেষ হয়ে গেছে।',expired:'সময় শেষ হয়ে গেছে, উত্তর জমা হয়নি। অ্যাডমিনের সাথে যোগাযোগ করো।',empty:'এই পরীক্ষায় এখনও প্রশ্ন যোগ করা হয়নি।'}[e.state];
  let act='';
  if(canOnline(e))act=`<button class="btn b-a pulse" data-act="startExam" data-arg="${e.id}">${e.state==='in_progress'?'চালিয়ে যাও':'পরীক্ষা শুরু করো'}</button>`;
  if(e.state==='done')act=e.result?`<button class="btn b-i" data-act="openResult" data-arg="${e.result.result_id}">ফলাফল দেখো</button>`:`<div class="card mut" style="line-height:1.6">${esc(e.note||'ফলাফল পরে প্রকাশ হবে।')}</div>`;
  if(e.state==='locked')act=`<button class="btn b-i" data-go="batches">ব্যাচে যুক্ত হও</button>`;
  if((e.mode==='omr'||e.state==='omr'||e.choice==='omr')&&e.state!=='done'&&e.state!=='locked')act=`<button class="btn b-i" data-go="paper:${e.id}">প্রশ্নপত্র দেখো</button><button class="btn b-w" data-go="omr">OMR শিট জমা দাও</button>`;
  else if(e.mode==='both'&&e.hasOmr&&!e.choice&&canOnline(e))act+=`<button class="btn b-w" data-act="chooseOmr" data-arg="${e.id}">OMR-এ পরীক্ষা দেব</button>`;
  return {nonav:1,html:`${top('পরীক্ষার নির্দেশনা')}<div class="hero u"><span class="chip live">${stChip(e).replace(/<[^>]+>/g,'')}</span><b style="font-size:25px">${esc(e.title)}</b><div class="sub">${esc(e.batch)}</div><div class="stats" style="margin-top:6px"><div><b>${bn(e.n)}টি</b><span>প্রশ্ন</span></div><div><b>${bn(e.time)} মি.</b><span>সময়</span></div><div><b>${e.mode==='both'?'দুটোই':e.mode==='omr'?'OMR':'অনলাইন'}</b><span>পদ্ধতি</span></div></div></div>${msg?`<div class="card u mut" style="line-height:1.6">${msg}</div>`:''}<div class="card u" style="animation-delay:.2s"><b style="font-size:17px;display:block;margin-bottom:12px">নিয়মাবলি</b>${['শুরু করার পর সময় থামবে না','একবারের বেশি পরীক্ষা দেওয়া যাবে না','সময় শেষ হলে উত্তর নিজে থেকেই জমা হবে','পরীক্ষা চলাকালীন অ্যাপ বন্ধ করো না'].map(t=>`<div class="row" style="align-items:flex-start;margin-bottom:10px;line-height:1.5">${ic('check','#0E8F7A',20)}<span>${t}</span></div>`).join('')}</div><div style="margin-top:auto;display:flex;flex-direction:column;gap:10px">${act}</div>`}
};
/* ---------- taking an exam / practice ---------- */
R.exam=()=>{
  if(!E)return {html:'<div class="empty">কোনো পরীক্ষা চলছে না</div>'+nav('exams')};
  const q=E.qs[E.idx],ans=E.ans[E.idx],pr=E.kind==='practice',last=E.idx===E.qs.length-1,n=E.qs.length;
  const big=n>60,lo=big?Math.max(0,E.idx-12):0,hi=big?Math.min(n,E.idx+13):n;
  const pal=E.qs.slice(lo,hi).map((_,j)=>{const i=lo+j;return `<button class="${i===E.idx?'cu':E.ans[i]!==undefined?'an':''}" data-act="jump" data-arg="${i}">${bn(i+1)}</button>`}).join('');
  const opts=q.o.map((o,i)=>`<button class="opt ${ans===i?'sel':''}" data-act="pick" data-arg="${i}"><span class="l">${'কখগঘ'[i]}</span><span class="grow1">${esc(o)}</span></button>`).join('');
  return {nonav:1,noanim:1,html:`<div class="row"><button class="ib" data-act="leave" aria-label="বন্ধ">${ic('x')}</button><div class="grow1"><b style="font-size:17px">${esc(E.title)}</b><div class="mut">প্রশ্ন ${bn(E.idx+1)} / ${bn(n)}${pr?' · প্র্যাকটিস':''}</div></div>${pr?'':`<div class="timer" id="tm">${fmt(Math.max(E.left,0))}</div>`}</div>${bar(Math.round((E.idx+1)*100/n),'#0E8F7A')}<div class="pal">${pal}</div><div class="card"><span style="font-size:13px;color:#4B3FD8;font-weight:600">${esc(q.s)}</span><p style="margin:8px 0 0;font-size:20px;line-height:1.5;font-weight:500">${esc(q.t)}</p></div><div style="display:flex;flex-direction:column;gap:10px">${opts}</div><div class="row" style="margin-top:auto;padding-top:6px"><button class="btn b-w" style="flex:1" data-act="prevQ" ${E.idx?'':'disabled'}>আগের</button><button class="btn b-i" style="flex:2" data-act="${last?'finish':'nextQ'}">${last?'জমা দাও':'পরের প্রশ্ন'}</button></div>`}
};
function startRun(kind,id,eid,title,qs,sec){
  if(!qs.length)return toast('কোনো প্রশ্ন পাওয়া যায়নি');
  E={kind,id,eid,title,qs,idx:0,ans:{},left:sec||0,busy:false};
  if(kind==='exam'){clearInterval(tmr);tmr=setInterval(()=>{E.left--;const t=$('#tm');if(t)t.textContent=fmt(Math.max(E.left,0));if(E.left<=0){clearInterval(tmr);tmr=null;toast('সময় শেষ! উত্তর জমা হচ্ছে…');finish(true)}},1000)}
  go('exam');
}
function leaveExam(){sheet(`<b style="font-size:20px">${E.kind==='exam'?'পরীক্ষা ছেড়ে বের হবে?':'প্র্যাকটিস ছেড়ে বের হবে?'}</b><div class="mut" style="line-height:1.6">${E.kind==='exam'?'বের হলেও তোমার সময় চলতে থাকবে। পরে "চালিয়ে যাও" দিয়ে ফিরতে পারবে, তবে এখনকার উত্তরগুলো ফোনে সংরক্ষিত থাকে না।':'এই প্র্যাকটিসের উত্তর জমা হবে না।'}</div><button class="btn b-i" data-act="closeSheet">চালিয়ে যাও</button><button class="btn b-l" data-act="quit">বের হও</button>`)}
function mkAttempt(ex,res){
  const qs=res.review.length?res.review:ex.qs.map((q,i)=>Object.assign({},q,{y:ex.ans[i]}));
  let c=res.correct,w=res.wrong,s=res.skipped;
  if(c===undefined){c=0;w=0;s=0;qs.forEach(q=>{if(q.y===undefined)s++;else if(q.a!==undefined){q.y===q.a?c++:w++}})}
  return {title:ex.title,kind:ex.kind,qs,correct:c,wrong:w===undefined?0:w,skipped:s===undefined?0:s,total:res.total||qs.length,percent:res.percent,marks:res.marks,max:res.max,rank:res.rank,participants:res.participants,msg:res.msg};
}
async function finish(auto){
  if(!E||E.busy)return;E.busy=true;clearInterval(tmr);tmr=null;
  try{
    const res=E.kind==='exam'?await API.submitExam(E.id,E.qs,E.ans):await API.submitPractice(E.eid,E.qs,E.ans);
    const x=E;E=null;hist=hist.filter(h=>h!=='exam');
    if(res.hidden){hist=[];cur='exams';draw();loadAll();sheet(`<b style="font-size:20px">জমা হয়েছে ✓</b><div class="mut" style="line-height:1.6">${esc(res.msg)}</div><button class="btn b-i" data-act="closeSheet">ঠিক আছে</button>`);return}
    S.attempts.push(mkAttempt(x,res));cur='result:'+(S.attempts.length-1);draw();loadAll();
  }catch(e){
    if(!E)return;E.busy=false;
    if(/ইতিমধ্যে/.test(e.message)){E=null;hist=[];cur='exams';draw();loadAll();return toast(e.message)}
    if(auto){toast('জমা হয়নি — ইন্টারনেট দেখো, আবার চেষ্টা হচ্ছে…');setTimeout(()=>finish(true),4000)}else toast('জমা হয়নি: '+e.message);
  }
}
/* ---------- results ---------- */
R.result=i=>{
  const a=S.attempts[+i];if(!a)return {nonav:1,html:top('ফলাফল')+'<div class="empty">ফলাফল নেই</div>'};
  const pct=pctOf(a),off=264-264*Math.min(pct,100)/100,grp={};a.qs.forEach(q=>{const k=q.s||'';grp[k]=grp[k]||[0,0];grp[k][1]++;if(q.y!==undefined&&q.y===q.a)grp[k][0]++});
  const keys=Object.keys(grp).filter(k=>k),cs=['#0E8F7A','#7C6BFF','#FFB020','#D9573B'];
  const center=a.max!==undefined&&a.max!==null?bn(a.marks)+'/'+bn(a.max):bn(a.correct)+'/'+bn(a.total);
  return {nonav:1,html:`${top('ফলাফল',esc(a.title))}<div class="hero u" style="flex-direction:row;align-items:center;gap:18px"><svg width="116" height="116" viewBox="0 0 104 104" role="img" aria-label="স্কোর"><circle cx="52" cy="52" r="42" fill="none" stroke="#2F2A9E" stroke-width="9"/><circle cx="52" cy="52" r="42" fill="none" stroke="#FFB020" stroke-width="9" stroke-linecap="round" stroke-dasharray="264" stroke-dashoffset="${off}" transform="rotate(-90 52 52)" style="animation:ring 1.8s both"/><text x="52" y="58" text-anchor="middle" fill="#fff" font-family="Sora" font-weight="700" font-size="${center.length>7?15:20}">${center}</text></svg><div>${a.rank?`<div class="sub">তোমার র‍্যাংক</div><b style="font-size:34px;font-family:Sora">#${bn(a.rank)}</b><div class="sub">${bn(a.participants)} জনের মধ্যে</div>`:`<div class="sub">সঠিক উত্তর</div><b style="font-size:34px;font-family:Sora">${bn(pct)}%</b>`}</div></div><div class="stats u" style="animation-delay:.1s">${[[a.correct,'সঠিক','#0E8F7A'],[a.wrong,'ভুল','#D9573B'],[a.skipped,'বাদ','#B87500']].map(([v,l,c])=>`<div class="lstat"><b style="color:${c};font-family:Sora">${bn(v)}</b><span>${l}</span></div>`).join('')}</div>${keys.length?`<div class="card u" style="animation-delay:.2s"><b style="font-size:17px;display:block;margin-bottom:12px">টপিকভিত্তিক বিশ্লেষণ</b>${keys.map((k,j)=>{const p=Math.round(grp[k][0]*100/grp[k][1]);return `<div style="margin-bottom:12px"><div class="row" style="justify-content:space-between;font-size:14px;margin-bottom:6px"><span>${esc(k)}</span><b>${bn(p)}%</b></div>${bar(p,cs[j%4])}</div>`}).join('')}</div>`:''}${a.msg&&a.kind==='practice'?`<div class="card u mut" style="line-height:1.6">${esc(a.msg)}</div>`:''}<div style="margin-top:auto;display:flex;flex-direction:column;gap:10px">${a.qs.length?`<button class="btn b-i" data-go="sol:${i}:0">সমাধান দেখো</button>`:''}<button class="btn b-w" data-tab="results">সব ফলাফল</button></div>`}
};
R.sol=(i,qi)=>{
  const a=S.attempts[+i];if(!a)return {nonav:1,html:top('সমাধান')};const n=+qi,q=a.qs[n];
  const wrong=q.y!==q.a;
  const op=q.o.map((o,k)=>`<div class="opt ${k===q.a?'ok':k===q.y?'no':''}"><span class="l">${'কখগঘ'[k]}</span><span class="grow1">${esc(o)}</span>${k===q.a?chip('সঠিক','g'):k===q.y?chip('তোমার উত্তর','r'):''}</div>`).join('');
  return {nonav:1,noanim:1,html:`${top('সমাধান','প্রশ্ন '+bn(n+1)+' / '+bn(a.qs.length))}<div class="card"><span style="font-size:13px;color:#4B3FD8;font-weight:600">${esc(q.s)}</span><p style="margin:8px 0 0;font-size:19px;line-height:1.5;font-weight:500">${esc(q.t)}</p></div><div style="display:flex;flex-direction:column;gap:10px">${op}</div>${q.y===undefined?'<div class="mut">তুমি এই প্রশ্নের উত্তর দাওনি।</div>':''}${q.x?`<div class="card" style="border:1px solid #D9D5FA"><div class="row" style="margin-bottom:6px">${ti('i','spark')}<b>ব্যাখ্যা</b></div><div style="line-height:1.6;color:#3A3D63;white-space:pre-wrap">${esc(q.x)}</div></div>`:''}${a.kind==='practice'&&wrong?`<div class="card" style="border:1px solid #D9D5FA"><div class="row" style="margin-bottom:8px">${ti('i','spark')}<b style="font-size:16px">AI ব্যাখ্যা</b></div><div id="ai" style="line-height:1.6;color:#3A3D63;white-space:pre-wrap"><button class="btn b-l sm" data-act="explain" data-arg="${i}:${n}">🤖 AI দিয়ে ব্যাখ্যা দেখো</button></div></div>`:''}<div class="row" style="margin-top:auto"><button class="btn b-w" style="flex:1" data-go="sol:${i}:${n-1}" data-rep="1" ${n?'':'disabled'}>আগের</button><button class="btn b-i" style="flex:2" data-go="sol:${i}:${n+1}" data-rep="1" ${n<a.qs.length-1?'':'disabled'}>পরের</button></div>`}
};
const histRow=h=>{const done=/complet/i.test(h.status),lab=/adapt/i.test(h.type)?'অ্যাডাপটিভ':'প্র্যাকটিস';return `<div class="card row">${ti(done?'g':'a','book')}<div class="grow1"><b style="font-weight:600">${lab} #${bn(h.id)}</b><div class="mut">${h.ms?dtS(h.ms):''}</div></div>${done?`<b style="font-family:Sora">${h.score!=null?bn(Math.round(h.score))+'%':''}</b>`:chip('অসমাপ্ত','a')}</div>`};
R.results=()=>{
  const online=DB.exams.filter(e=>e.state==='done'),omr=DB.omr.filter(o=>o.result||o.hidden||o.sub);
  return {html:`${top('ফলাফল','তোমার সব পরীক্ষার ফল')}<div class="card row u"><span class="ti g">${ic('chart','currentColor',24)}</span><div class="grow1"><b>ফলাফল প্রকাশিত পরীক্ষা</b><div class="mut">ব্যাচ পরীক্ষা</div></div><b style="font-family:Sora;font-size:22px">${bn(DB.perf.done)}</b></div>
${online.length?`<b style="font-size:17px">অনলাইন পরীক্ষা</b>${online.map(e=>`<div class="card row t" ${e.result?`data-act="openResult" data-arg="${e.result.result_id}"`:''}>${ti('b','chart')}<div class="grow1"><b style="font-weight:600">${esc(e.title)}</b><div class="mut">${e.result?'বিস্তারিত দেখতে ট্যাপ করো':esc(e.note||'ফলাফল পরে প্রকাশ হবে')}</div></div>${e.result?`<b style="font-family:Sora">${bn(e.result.marks)}/${bn(e.result.max_marks)}</b>`:''}</div>`).join('')}`:''}
${omr.length?`<b style="font-size:17px">OMR পরীক্ষা</b>${omr.map(o=>`<div class="card row t" ${o.result?`data-act="openOmr" data-arg="${o.id}"`:''}>${ti('p','omr')}<div class="grow1"><b style="font-weight:600">${esc(o.title)}</b><div class="mut">${o.result?'বিস্তারিত দেখতে ট্যাপ করো':o.hidden?esc(o.note||'ফলাফল পরে প্রকাশ হবে'):o.sub&&o.sub.status==='published'?'স্ক্যান হয়েছে':'জমা হয়েছে, স্ক্যানের অপেক্ষায়'}</div></div>${o.result?`<b style="font-family:Sora">${bn(o.result.marks)}/${bn(o.result.max_marks)}</b>`:''}</div>`).join('')}`:''}
${DB.hist.length?`<b style="font-size:17px">প্র্যাকটিস ও অ্যাডাপটিভ</b>${DB.hist.slice(0,20).map(histRow).join('')}`:''}
${(!online.length&&!omr.length&&!DB.hist.length)?'<div class="empty">এখনও কোনো পরীক্ষা দাওনি।<br><br><button class="btn b-i sm" style="width:auto;padding:0 24px" data-go="exams">পরীক্ষা দেখো</button></div>':''}${nav('results')}`}
};
/* ---------- practice / adaptive ---------- */
R.practice=()=>({html:`${top('প্র্যাকটিস','ব্যাচ পরীক্ষা থেকে প্রশ্ন')}<div class="hero u"><span class="chip live">র‍্যান্ডম প্র্যাকটিস</span><b style="font-size:23px;line-height:1.3">নিজেকে যাচাই করো</b><span class="sub">তোমার ব্যাচের শেষ হয়ে যাওয়া পরীক্ষা থেকে ১০টি প্রশ্ন। জমা দিলে সঠিক উত্তর ও AI ব্যাখ্যা পাবে।</span><button class="btn b-a pulse" data-act="practiceRandom">প্র্যাকটিস শুরু করো</button></div>${DB.pex.length?`<b class="u" style="font-size:17px">পরীক্ষা ধরে প্র্যাকটিস</b>${DB.pex.map(p=>`<div class="card row">${ti('g','book')}<div class="grow1"><b style="font-weight:600">${esc(p.title)}</b><div class="mut">${esc(p.batch)} · ${bn(p.n)} প্রশ্ন</div></div>${p.open?`<button class="btn sm b-l" style="width:auto;padding:0 16px" data-act="practiceExam" data-arg="${p.id}">শুরু</button>`:chip('শেষ হলে খুলবে','i')}</div>`).join('')}`:''}${DB.hist.length?`<b class="u" style="font-size:17px">প্র্যাকটিস হিস্ট্রি</b>${DB.hist.slice(0,10).map(histRow).join('')}`:''}${nav('exams')}`});
R.adaptive=()=>{const P=DB.perf,need=Math.max(P.need-P.done,0);
  return {html:`${top('অ্যাডাপটিভ প্র্যাকটিস','ভুল থেকে শেখো')}<div class="hero u"><span class="chip live">তোমার জন্য বাছাই</span><b style="font-size:24px;line-height:1.3">দুর্বল টপিক নিয়ে আবার চর্চা</b><span class="sub">ব্যাচ পরীক্ষার ভুল থেকে সিস্টেম নতুন প্র্যাকটিস সেট বানাবে।</span>${P.ready?'<span class="chip live" style="background:#0E8F7A;color:#fff">প্রস্তুত ✓</span>':`<div class="sub">আরও ${bn(need)}টি পরীক্ষা শেষ করলে চালু হবে (${bn(P.done)}/${bn(P.need)})</div>${bar(P.need?Math.round(P.done*100/P.need):0,'#FFB020')}`}</div><div class="card u" style="animation-delay:.2s"><b style="font-size:17px;display:block;margin-bottom:12px">টপিক অনুযায়ী পারফরম্যান্স</b>${P.topics.length?P.topics.map(t=>`<div style="margin-bottom:12px"><div class="row" style="justify-content:space-between;font-size:15px;margin-bottom:6px"><span>${esc(t.n)}</span><b>${bn(t.p)}%</b></div>${bar(t.p,t.p<50?'#D9573B':t.p<70?'#C98A00':'#0E8F7A')}</div>`).join(''):'<div class="mut">পরীক্ষা দিলে এখানে টপিকভিত্তিক ফল দেখা যাবে।</div>'}</div><div style="margin-top:auto"><button class="btn b-i" data-act="startAdaptive" ${P.ready?'':'disabled'}>অ্যাডাপটিভ সেট শুরু করো</button></div>${nav('exams')}`}
};
/* ---------- batches ---------- */
const bSt=b=>({active:['যুক্ত আছো','g'],pending:['অনুমোদনের অপেক্ষায়','a'],rejected:['বাতিল','r']}[b.state]||(b.fee?['৳'+bn(b.fee),'a']:['ফ্রি','g']));
R.batches=()=>({html:`${top('ব্যাচ','তোমার ব্যাচ ও নতুন ব্যাচ')}${DB.batches.length?DB.batches.map((b,i)=>`<div class="card row t u" style="animation-delay:.${i%8}s" data-go="batch:${b.id}">${ti('i','team')}<div class="grow1"><b style="font-size:16px">${esc(b.title)}</b><div class="mut">${bn(b.exams)}টি পরীক্ষা</div></div>${chip(...bSt(b))}</div>`).join(''):'<div class="empty">কোনো ব্যাচ পাওয়া যায়নি</div>'}${nav('exams')}`});
R.batch=id=>{
  const b=DB.batches.find(x=>String(x.id)===String(id));if(!b)return {nonav:1,html:top('ব্যাচ')};
  const act=b.state==='active'?'<button class="btn b-l" disabled>তুমি এই ব্যাচে আছো</button>':b.state==='pending'?'<button class="btn b-l" disabled>পেমেন্ট যাচাই চলছে</button>':`<button class="btn b-i" data-act="join" data-arg="${b.id}">${b.state==='rejected'?'আবার আবেদন করো · ':''}${b.fee?'ভর্তি হও ৳'+bn(b.fee):'এখনই যোগ দাও'}</button>`;
  return {nonav:1,html:`${top('ব্যাচের বিস্তারিত')}<div class="hero u"><span class="chip live">${bSt(b)[0]}</span><b style="font-size:27px;line-height:1.25">${esc(b.title)}</b><div class="stats" style="margin-top:6px"><div><b>${bn(b.exams)}টি</b><span>পরীক্ষা</span></div><div style="background:rgba(255,176,32,.2)"><b style="color:#FFB020">${b.fee?'৳'+bn(b.fee):'ফ্রি'}</b><span>ফি</span></div></div></div><div class="card u" style="animation-delay:.2s"><b style="font-size:18px;display:block;margin-bottom:12px">এই ব্যাচে যা পাবে</b>${[['i','book','লাইভ পরীক্ষা','নির্দিষ্ট সময়ে সবার সাথে'],['g','book','প্র্যাকটিস প্রশ্ন','পরীক্ষার পর যতবার ইচ্ছা'],['b','omr','OMR পরীক্ষা','ছবি তুলে শিট জমা'],['r','chart','ফলাফল ও র‍্যাংকিং','বিষয় অনুযায়ী বিশ্লেষণ']].map(([k,i,t,d])=>`<div class="row" style="margin-bottom:12px">${ti(k,i)}<div><b style="font-size:16px">${t}</b><div class="mut">${d}</div></div></div>`).join('')}</div>${b.state==='active'&&b.list.length?`<div class="card u"><b style="font-size:17px;display:block;margin-bottom:12px">পরীক্ষাসমূহ</b>${b.list.map(x=>`<div class="row" style="margin-bottom:10px"><div class="grow1"><b style="font-weight:500">${esc(x.title)}</b><div class="mut">${bn(x.qn)} প্রশ্ন</div></div>${x.done?chip('সম্পন্ন','g'):chip(x.mode==='omr'?'OMR':'চালু','i')}</div>`).join('')}</div>`:''}<div style="margin-top:auto">${act}</div>`}
};
/* ---------- OMR ---------- */
R.omr=()=>({html:`${top('ওএমআর','খাতায় পরীক্ষা দিয়ে ছবি জমা')}${DB.omr.length?DB.omr.map((o,i)=>{
  const st=o.sub?(o.sub.status==='published'?chip('স্ক্যান হয়েছে','g'):chip('জমা হয়েছে','a')):'';
  let btns='';
  if(o.needsChoice)btns+=`<button class="btn sm b-l" data-act="chooseOmr" data-arg="${o.id}">OMR-এ পরীক্ষা দেব</button>`;
  if(o.canPaper)btns+=`<button class="btn sm b-w" data-go="paper:${o.id}">প্রশ্নপত্র দেখো</button>`;
  if(o.canSubmit)btns+=`<button class="btn sm b-i" data-go="omrup:${o.id}">${o.sub?'আবার ছবি জমা দাও':'শিট জমা দাও'}</button>`;
  if(o.result)btns+=`<button class="btn sm b-l" data-act="openOmr" data-arg="${o.id}">ফলাফল ${bn(o.result.marks)}/${bn(o.result.max_marks)}</button>`;
  return `<div class="card u" style="animation-delay:.${i%8}s"><div class="row" style="margin-bottom:8px">${ti('p','omr')}<div class="grow1"><b style="font-size:16px">${esc(o.title)}</b><div class="mut">${bn(o.n)} প্রশ্ন${o.end?' · শেষ: '+esc(String(o.end).slice(0,16).replace('T',' ')):''}</div></div>${st}</div>${o.sub&&o.sub.error?`<div class="mut" style="color:#B03F27;margin-bottom:8px">${esc(o.sub.error)}</div>`:''}${o.hidden?`<div class="mut" style="margin-bottom:8px">${esc(o.note||'ফলাফল পরে প্রকাশ হবে')}</div>`:''}<div style="display:flex;flex-direction:column;gap:8px">${btns||'<div class="mut">এখন কোনো কাজ নেই</div>'}</div></div>`}).join(''):'<div class="card mut" style="line-height:1.6">কোনো OMR পরীক্ষা নেই। আগে একটি ব্যাচে যুক্ত হও এবং অনুমোদন নাও।</div>'}${nav('exams')}`});
R.omrup=id=>{const o=DB.omr.find(x=>String(x.id)===String(id))||{title:'OMR'};
  return {dark:1,nonav:1,html:`${top('শিটের ছবি জমা',esc(o.title))}<div class="cam u">${omrFile?`<img id="pv" alt="ওএমআর শিট">`:`<div class="mut" style="padding:24px;text-align:center;line-height:1.7">শিটটি সমতল জায়গায় রেখে পুরো শিট দেখা যায় এমন ছবি তোলো। আলো যেন ভালো থাকে।<br>(JPG বা PNG)</div>`}</div><input type="file" id="fcam" accept="image/*" capture="environment" hidden><input type="file" id="fgal" accept="image/*" hidden><div class="row"><button class="ib" data-act="pickGal" aria-label="গ্যালারি">${ic('img')}</button><button class="btn b-a ${omrFile?'':'pulse'}" style="height:62px" data-act="${omrFile?'sendOmr':'pickCam'}" data-arg="${id}">${omrFile?'শিট জমা দাও':'ছবি তোলো'}</button></div>`,after(){const set=e=>{omrFile=e.target.files[0]||null;draw()};$('#fcam').onchange=set;$('#fgal').onchange=set;if(omrFile)$('#pv').src=URL.createObjectURL(omrFile)},cleanup:()=>{}}};
R.paper=id=>({nonav:1,html:`${top('প্রশ্নপত্র',esc((ex(id)||DB.omr.find(o=>String(o.id)===String(id))||{}).title||''))}<div id="pp" class="empty">লোড হচ্ছে…</div>`,after(){API.paper(id).then(p=>{const d=$('#pp');if(!d||!cur.startsWith('paper'))return;d.className='';d.innerHTML=`<div class="card mut" style="margin-bottom:12px">সময়: ${bn(Math.round((p.sec||0)/60))} মিনিট · ${bn(p.qs.length)}টি প্রশ্ন</div>`+p.qs.map(q=>`<div class="card" style="margin-bottom:10px"><b style="line-height:1.5">${bn(q.no)}. ${esc(q.t)}</b>${q.o.map((o,i)=>`<div style="margin-top:6px">${'কখগঘ'[i]}) ${esc(o)}</div>`).join('')}</div>`).join('')}).catch(e=>{const d=$('#pp');if(d)d.textContent=e.message})}});
/* ---------- leaderboard ---------- */
R.board=()=>{
  const list=DB.board,cs=['#FFB020','#C9CCF5','#E08A5B'],t=list.slice(0,3),ord=[1,0,2].filter(i=>t[i]),mine=S.user&&S.user.id;
  return {html:`${top('লিডারবোর্ড','প্র্যাকটিসের গড় স্কোর (কমপক্ষে ৩টি)')}<div class="pod u">${ord.map(i=>`<div><span class="av" style="background:${cs[i]}">${esc(t[i].n[0])}</span>${esc(t[i].n.split(' ')[0])}<i style="height:${[130,90,70][i]}px;background:${cs[i]}">${bn(i+1)}</i></div>`).join('')}</div>${list.slice(3).map((b,i)=>`<div class="card row u" style="${String(b.id)===String(mine)?'background:#E6E4FB;border:1px solid #FFB020':''}"><b style="width:28px;font-family:Sora;color:#5C5F85">${bn(i+4)}</b><span class="ti s" style="width:38px;height:38px;border-radius:50%">${esc(b.n[0])}</span><b class="grow1" style="font-size:16px">${esc(b.n)}</b><b style="font-family:Sora;color:#B87500">${bn(b.s)}%</b></div>`).join('')}${list.length?'':'<div class="empty">লিডারবোর্ডে এখনও কেউ নেই<br>৩টি প্র্যাকটিস পরীক্ষা শেষ করলে নাম আসবে</div>'}${nav('results')}`}
};
/* ---------- attendance + face ---------- */
R.attend=()=>{
  const F=DB.face,cls=F.recent.filter(r=>r.kind==='class'&&r.ms),set={};cls.forEach(r=>{set[dayKey(new Date(r.ms))]=r.ms});
  const days=[...Array(7)].map((_,i)=>{const d=new Date();d.setDate(d.getDate()-(6-i));return {k:dayKey(d),l:['রবি','সোম','মঙ্গল','বুধ','বৃহ','শুক্র','শনি'][d.getDay()]}});
  const t=set[dayKey()],ok=F.enrolled&&F.status==='approved';
  const hero=`<div class="hero u" style="flex-direction:row;align-items:center;gap:16px"><div style="width:72px;height:72px;border-radius:50%;border:3px solid #FFB020;overflow:hidden;display:flex;align-items:center;justify-content:center;background:#2F2A9E;flex:none">${F.photo?`<img src="${esc(F.photo)}" alt="" style="width:100%;height:100%;object-fit:cover">`:ic('user','#fff',34)}</div><div><div class="sub">পার্সোনাল কেয়ার</div><b style="font-size:22px">${!F.enrolled?'যুক্ত নও':!ok?'অনুমোদনের অপেক্ষায়':t?'আজ উপস্থিত':'আজ অনুপস্থিত'}</b><div class="sub">${!F.enrolled?'ছবি দিয়ে যুক্ত হও':!ok?'অ্যাডমিন ছবি যাচাই করলে হাজিরা দেওয়া যাবে':t?tmS(t)+' এ হাজিরা হয়েছে':'এখনও হাজিরা দাওনি'}</div></div></div>`;
  const recent=F.recent.length?`<div class="card u" style="animation-delay:.2s"><b style="font-size:17px;display:block;margin-bottom:12px">সাম্প্রতিক উপস্থিতি</b>${F.recent.slice(0,8).map(r=>`<div class="row" style="margin-bottom:10px"><i style="width:10px;height:10px;border-radius:50%;background:#0E8F7A"></i><b class="grow1" style="font-weight:500">${r.kind==='exam'?'পরীক্ষা: '+esc(r.title||''):'ক্লাস হাজিরা'}</b><span class="mut">${r.ms?dtS(r.ms):''}</span></div>`).join('')}</div>`:'';
  if(!F.enrolled)return {html:`${top('অ্যাটেনডেন্স','পার্সোনাল কেয়ার')}${hero}<div class="card u" style="line-height:1.6;animation-delay:.1s">পার্সোনাল কেয়ারে যুক্ত হতে তোমার একটি স্পষ্ট ছবি লাগবে। সিস্টেম তোমার চেহারার সংখ্যাভিত্তিক তথ্য (descriptor) ও ছোট ছবি সার্ভারে রাখে — ফোনে কিছু রাখা হয় না।</div>${recent}<div style="margin-top:auto"><button class="btn b-a pulse" data-go="face:enroll">ছবি তুলে যুক্ত হও</button></div>${nav('more')}`};
  return {html:`${top('অ্যাটেনডেন্স','ফেস দিয়ে হাজিরা')}${hero}<div class="card u" style="animation-delay:.1s"><b style="font-size:17px;display:block;margin-bottom:14px">এই সপ্তাহ</b><div class="row" style="justify-content:space-between">${days.map(d=>{const p=!!set[d.k];return `<div style="display:flex;flex-direction:column;align-items:center;gap:6px;font-size:12px;color:#5C5F85"><span style="width:34px;height:34px;border-radius:50%;background:${p?'#0E8F7A':'#FCE1DC'};display:flex;align-items:center;justify-content:center">${ic(p?'check':'x',p?'#fff':'#D9573B',18)}</span>${d.l}</div>`}).join('')}</div></div>${recent}<div style="margin-top:auto;display:flex;flex-direction:column;gap:10px">${ok?'<button class="btn b-a pulse" data-go="face:attend">হাজিরা দাও</button>':''}<button class="btn b-w sm" data-act="faceLeave">পার্সোনাল কেয়ার ছেড়ে দাও</button></div>${nav('more')}`}
};
const say=t=>{const f=$('#fs');if(f)f.textContent=t};
const FACE_CDN='https://cdn.jsdelivr.net/npm/@vladmandic/face-api@1.7.12';let faceP=null;
const Face={
  load(){if(!faceP){faceP=(async()=>{
    if(!window.faceapi)await new Promise((ok,no)=>{const s=document.createElement('script');s.src=FACE_CDN+'/dist/face-api.js';s.onload=ok;s.onerror=()=>no(new Error('ফেস লাইব্রেরি লোড হয়নি — ইন্টারনেট দেখো'));document.head.appendChild(s)});
    await Promise.all([faceapi.nets.tinyFaceDetector,faceapi.nets.faceLandmark68Net,faceapi.nets.faceRecognitionNet].map(n=>n.loadFromUri(FACE_CDN+'/model/')))})().catch(e=>{faceP=null;throw e})}return faceP},
  detect:src=>faceapi.detectSingleFace(src,new faceapi.TinyFaceDetectorOptions({inputSize:320,scoreThreshold:.5})).withFaceLandmarks().withFaceDescriptor(),
  thumb(src,b){const c=document.createElement('canvas');c.width=c.height=220;const x=c.getContext('2d'),pad=b.width*.35,sx=Math.max(0,b.x-pad),sy=Math.max(0,b.y-pad),sw=b.width+pad*2,sh=b.height+pad*2;x.drawImage(src,sx,sy,sw,sh,0,0,220,220);return c.toDataURL('image/jpeg',.75)}
};
R.face=(mode,arg)=>{
  const T={attend:'ফেস দিয়ে হাজিরা',enroll:'ছবি তুলে যুক্ত হও',exam:'পরীক্ষার আগে ফেস যাচাই'}[mode]||'ফেস';
  return {dark:1,nonav:1,html:`${top(T,'পরিচয় নিশ্চিত করা হবে')}<div style="position:relative;margin:10px 0"><div class="faceC"><i class="ring2"></i><video id="vid" autoplay playsinline muted></video></div></div><div class="u" style="text-align:center"><b style="font-size:20px">ক্যামেরার দিকে সোজা তাকাও</b><div class="mut" id="fs" style="margin-top:6px">প্রস্তুত হচ্ছে…</div></div><div class="card u" style="background:#181B4A;color:#F4F5FF">${['ভালো আলোতে থাকো','চশমা বা মাস্ক খুলে ফেলো','ফোন স্থির ধরে রাখো'].map(t=>`<div class="row" style="padding:4px 0">${ic('check','#FFB020',20)}<span>${t}</span></div>`).join('')}</div>${mode==='enroll'?'<label class="row" style="align-items:flex-start;font-size:14px;line-height:1.5;color:#C9CCF5"><input type="checkbox" id="cons" style="width:22px;height:22px;margin-top:2px"><span>আমি সম্মত — আমার ছবি ও চেহারার ডেটা হাজিরার জন্য সার্ভারে সংরক্ষিত থাকবে।</span></label><input type="file" id="ffile" accept="image/*" hidden>':''}<div style="margin-top:auto;display:flex;flex-direction:column;gap:10px"><button class="btn b-a pulse" data-act="faceGo" data-arg="${mode}:${arg||''}">${mode==='enroll'?'ছবি তুলে সংরক্ষণ করো':'যাচাই করো'}</button>${mode==='enroll'?'<button class="btn b-o" data-act="faceGallery">গ্যালারির ছবি দিয়ে</button>':''}<button class="btn b-o" data-act="back">বাতিল</button></div>`,
  after(){(async()=>{try{
    say('ফেস মডেল লোড হচ্ছে…');await Face.load();if(!cur.startsWith('face'))return;
    if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia)throw new Error('এই ডিভাইসে ক্যামেরা পাওয়া যায়নি');
    say('ক্যামেরা চালু হচ্ছে…');const s=await navigator.mediaDevices.getUserMedia({video:{width:640,height:480,facingMode:'user'}});
    if(!cur.startsWith('face')){s.getTracks().forEach(t=>t.stop());return}
    stream=s;const v=$('#vid');v.srcObject=s;await v.play();say('প্রস্তুত — নিচের বাটনে চাপ দাও')}catch(e){say(e.message||'ক্যামেরার অনুমতি দাওনি')}})();
    const f=$('#ffile');if(f)f.onchange=e=>{if(e.target.files[0])faceFile(e.target.files[0])};
  },cleanup:()=>{if(stream){stream.getTracks().forEach(t=>t.stop());stream=null}if(faceRun)faceRun.stop=true}};
};
async function faceDone(msg){await loadAll();toast(msg);replaceWith('attend')}
async function faceScan(mode,arg){
  if(faceRun)return;const run=faceRun={stop:false},v=$('#vid');
  try{
    if(!v||!v.videoWidth)throw new Error('ক্যামেরা এখনও প্রস্তুত নয়');
    if(mode==='enroll'){
      const cb=$('#cons');if(cb&&!cb.checked)throw new Error('সম্মতি দিতে হবে');
      say('মুখ খোঁজা হচ্ছে…');let best=null;
      for(let i=0;i<14&&!run.stop;i++){const r=await Face.detect(v);if(r&&r.detection.score>.6){best=r;break}await new Promise(z=>setTimeout(z,400))}
      if(!best)throw new Error('মুখ পাওয়া যায়নি — আলোতে সোজা তাকাও');
      say('সংরক্ষণ হচ্ছে…');await API.faceEnroll(Array.from(best.descriptor),Face.thumb(v,best.detection.box),false);
      await faceDone('পার্সোনাল কেয়ারে যুক্ত হয়েছো ✓');
    }else{
      const eid=mode==='exam'?Number(arg):null,t0=Date.now();
      while(!run.stop&&Date.now()-t0<25000){
        const r=await Face.detect(v);
        if(r){say('মিলিয়ে দেখা হচ্ছে…');
          try{const out=await API.faceVerify(Array.from(r.descriptor),eid);
            if(mode==='exam'){replaceWith('instr:'+arg);toast('যাচাই সম্পন্ন ✓');A.doStart(arg)}
            else await faceDone(out.already?'আজ আগেই হাজিরা দেওয়া হয়েছে':'হাজিরা সম্পন্ন ✓');
            return}
          catch(e){if(e.code!=='NO_MATCH'&&e.status!==422)throw e;say('মুখ মেলেনি, আবার চেষ্টা হচ্ছে…')}
        }else say('মুখ খোঁজা হচ্ছে…');
        await new Promise(z=>setTimeout(z,500));
      }
      if(!run.stop)throw new Error('মুখ মেলেনি — আলোতে সোজা তাকিয়ে আবার চেষ্টা করো');
    }
  }catch(e){say(e.message);toast(e.message)}finally{faceRun=null}
}
async function faceFile(file){
  if(faceRun)return;faceRun={stop:false};const url=URL.createObjectURL(file);
  try{
    const cb=$('#cons');if(cb&&!cb.checked)throw new Error('সম্মতি দিতে হবে');
    say('ছবি পড়া হচ্ছে…');const img=await new Promise((ok,no)=>{const i=new Image();i.onload=()=>ok(i);i.onerror=()=>no(new Error('ছবি পড়া যায়নি'));i.src=url});
    const r=await Face.detect(img);if(!r)throw new Error('ছবিতে মুখ পাওয়া যায়নি');
    say('সংরক্ষণ হচ্ছে…');await API.faceEnroll(Array.from(r.descriptor),Face.thumb(img,r.detection.box),true);
    await faceDone('পার্সোনাল কেয়ারে যুক্ত হয়েছো ✓');
  }catch(e){say(e.message);toast(e.message)}finally{URL.revokeObjectURL(url);faceRun=null}
}
/* ---------- profile ---------- */
R.more=()=>{
  const m=[['i','user','আমার প্রোফাইল','act:profile'],['k','face','অ্যাটেনডেন্স','go:attend'],['a','card','পেমেন্ট ইতিহাস','go:pays'],['s','bell','নোটিফিকেশন','act:bell'],['b','web','ওয়েবসাইট খোলো','act:site'],['g','target','সংযোগ পরীক্ষা','go:diag'],['r','out','লগআউট','act:logout']];
  return {html:`${top('প্রোফাইল')}<div class="hero u" style="flex-direction:row;align-items:center;gap:14px"><div style="width:64px;height:64px;border-radius:50%;background:#FFB020;color:#1A1300;font-weight:700;font-size:28px;display:flex;align-items:center;justify-content:center">${esc(user()[0])}</div><div><b style="font-size:20px">${esc(user())}</b><div class="sub">${esc((S.user&&S.user.email)||'')}</div></div></div>${m.map(([k,i,l,a],n)=>{const t=a.slice(0,a.indexOf(':')),v=a.slice(a.indexOf(':')+1);return `<div class="card row t u" style="animation-delay:.${n}s" ${t==='go'?`data-go="${v}"`:`data-act="${v}"`}>${ti(k,i)}<b class="grow1" style="font-weight:500;font-size:16px">${l}</b>${ic('chev','#5C5F85',20)}</div>`}).join('')}${nav('more')}`}
};
R.pays=()=>{const L=DB.batches.filter(b=>b.fee>0&&b.state!=='none');return {html:`${top('পেমেন্ট ইতিহাস','সার্ভারের তথ্য অনুযায়ী')}${L.length?L.map(b=>`<div class="card row">${ti('a','card')}<div class="grow1"><b>${esc(b.title)}</b><div class="mut">৳${bn(b.fee)}</div></div>${chip(...bSt(b))}</div>`).join(''):'<div class="empty">কোনো পেইড ব্যাচে আবেদন করোনি</div>'}${nav('more')}`}};
R.diag=()=>({nonav:1,html:`${top('সংযোগ পরীক্ষা','সার্ভারের সাথে যোগাযোগ')}<div id="dg" class="card"><span class="mut">পরীক্ষা চলছে…</span></div><div class="card"><b>সাম্প্রতিক কল</b><pre id="lg" style="white-space:pre-wrap;word-break:break-all;font-size:11px;margin:8px 0 0"></pre></div>`,after(){API.diag().then(o=>{const d=$('#dg');if(!d)return;d.innerHTML=o.map(x=>`<div style="margin-bottom:10px;font-size:13px"><span class="chip c-${x.c>=200&&x.c<300?'g':'r'}">${x.c}</span> <code>${x.u}</code><div class="mut" style="word-break:break-all">${esc(x.t)}</div></div>`).join('');$('#lg').textContent=window.PA_LOG.map(l=>l.m+' '+l.u+' → '+l.c+' '+l.t.slice(0,120)).join('\n')})}});
/* ---------- data + actions ---------- */
async function loadAll(){
  const r=await Promise.allSettled([API.exams(),API.batches(),API.leaderboard(),API.performance(),API.history(),API.pexams(),API.omrOverview(),API.faceMe()]);
  ['exams','batches','board','perf','hist','pex','omr','face'].forEach((k,i)=>{if(r[i].status==='fulfilled')DB[k]=r[i].value});
  if(r[0].status==='rejected')toast('পরীক্ষা লোড হয়নি: '+r[0].reason.message);
}
async function enter(r){S.token=r.token;S.user=r.user;toast('লোড হচ্ছে…');await loadAll();go('home','root')}
const A={
  back(){if(!back())toast('এটাই প্রথম পেজ')},closeSheet,
  async login(){try{await enter(await API.login($('#em').value.trim(),$('#pw').value))}catch(e){toast(e.message)}},
  async register(){try{await enter(await API.register($('#nm').value.trim(),$('#em').value.trim(),$('#pw').value))}catch(e){toast(e.message)}},
  bell(){const n=DB.exams.filter(canOnline).length;toast(n?bn(n)+'টি পরীক্ষা এখন দেওয়া যাবে':'এখন কোনো চালু পরীক্ষা নেই')},
  profile(){toast(user()+(S.user&&S.user.email?' · '+S.user.email:''))},
  site(){window.Native&&window.Native.openUrl?window.Native.openUrl('https://prottashaacademy.com'):window.open('https://prottashaacademy.com')},
  logout(){S.token=null;S.user=null;S.attempts=[];E=null;API.setToken(null);Object.assign(DB,{exams:[],batches:[],board:[],hist:[],pex:[],omr:[],perf:{done:0,need:0,ready:false,topics:[]},face:{enrolled:false,status:null,photo:null,recent:[]}});go('login','root')},
  startExam(id){const e=ex(id);if(!e)return;if(e.state==='in_progress')return A.doStart(id);
    sheet(`<b style="font-size:20px">পরীক্ষা শুরু করবে?</b><div class="mut" style="line-height:1.6">শুরু করার পর সময় থামবে না এবং একবারের বেশি দেওয়া যাবে না।${e.mode==='both'?' অনলাইনে শুরু করলে এই পরীক্ষায় আর OMR দেওয়া যাবে না।':''}</div><button class="btn b-a" data-act="doStart" data-arg="${id}">শুরু করো</button><button class="btn b-l" data-act="closeSheet">এখন না</button>`)},
  async doStart(id){closeSheet();const e=ex(id);toast('পরীক্ষা শুরু হচ্ছে…');
    try{const r=await API.start(id);startRun('exam',id,null,e?e.title:r.title||'পরীক্ষা',r.qs,r.sec||(e&&e.sec))}
    catch(x){if(x.code==='FACE_REQUIRED'){toast(x.message);go('face:exam:'+id)}else toast(x.message)}},
  chooseOmr(id){sheet(`<b style="font-size:20px">OMR-এ পরীক্ষা দেবে?</b><div class="mut" style="line-height:1.6">একবার OMR বেছে নিলে আর অনলাইনে দেওয়া যাবে না।</div><button class="btn b-i" data-act="doChoose" data-arg="${id}">হ্যাঁ, OMR-এ দেব</button><button class="btn b-l" data-act="closeSheet">না</button>`)},
  async doChoose(id){closeSheet();try{await API.choose(id,'omr');await loadAll();toast('OMR বেছে নেওয়া হয়েছে ✓');draw()}catch(e){toast(e.message)}},
  pick(i){E.ans[E.idx]=+i;draw()},nextQ(){E.idx++;draw()},prevQ(){E.idx--;draw()},jump(i){E.idx=+i;draw()},
  leave(){leaveExam()},
  quit(){closeSheet();clearInterval(tmr);tmr=null;E=null;hist=hist.filter(h=>h!=='exam');cur=hist.pop()||'home';draw()},
  finish(){const un=E.qs.length-Object.keys(E.ans).length;if(!un)return finish();sheet(`<b style="font-size:20px">জমা দেবে?</b><div class="mut">${bn(un)}টি প্রশ্নের উত্তর দাওনি।</div><button class="btn b-l" data-act="closeSheet">ফিরে যাও</button><button class="btn b-i" data-act="doFinish">জমা দাও</button>`)},
  doFinish(){closeSheet();finish()},
  async openResult(rid){try{const r=await API.review(rid);const e=DB.exams.find(x=>x.result&&String(x.result.result_id)===String(rid));S.attempts.push(mkAttempt({title:e?e.title:'পরীক্ষার ফলাফল',kind:'exam',qs:[],ans:{}},Object.assign({},r,{percent:e&&e.result?e.result.score:r.percent,marks:e&&e.result?e.result.marks:r.marks,max:e&&e.result?e.result.max_marks:r.max,rank:e&&e.result?e.result.rank:r.rank,participants:e&&e.result?e.result.participants:r.participants})));go('result:'+(S.attempts.length-1))}catch(x){toast(x.message)}},
  async openOmr(id){const o=DB.omr.find(x=>String(x.id)===String(id));if(!o||!o.result)return;try{const qs=await API.omrReview(o.result.result_id);const r=o.result;S.attempts.push({title:o.title,kind:'omr',qs,correct:r.right,wrong:r.wrong,skipped:r.skipped,total:qs.length,marks:r.marks,max:r.max_marks,percent:r.max_marks?r.marks*100/r.max_marks:undefined,rank:r.rank,participants:r.participants});go('result:'+(S.attempts.length-1))}catch(x){toast(x.message)}},
  async explain(arg){const [i,n]=arg.split(':'),q=S.attempts[+i].qs[+n],el=$('#ai');el.innerHTML='<span class="mut">ব্যাখ্যা তৈরি হচ্ছে…</span>';try{el.textContent=await API.explain(q.id,q.y!==undefined?'abcd'[q.y]:null)}catch(e){el.textContent='ব্যাখ্যা আনা যায়নি: '+e.message}},
  async practiceRandom(){toast('প্রশ্ন তৈরি হচ্ছে…');try{const r=await API.generate({count:10});if(!r.qs.length)return toast(r.msg||'প্র্যাকটিসের জন্য প্রশ্ন নেই');startRun('practice',null,r.eid,'প্র্যাকটিস',r.qs)}catch(e){toast(e.message)}},
  async practiceExam(id){toast('প্রশ্ন তৈরি হচ্ছে…');try{const r=await API.generate({panel_exam_id:Number(id)});if(!r.qs.length)return toast(r.msg||'প্রশ্ন নেই');startRun('practice',null,r.eid,'প্র্যাকটিস',r.qs)}catch(e){toast(e.message)}},
  async startAdaptive(){toast('সেট তৈরি হচ্ছে…');try{const r=await API.adaptive();if(!r.qs.length)return toast(r.msg||'এখনও কোনো দুর্বল টপিক নেই');startRun('practice',null,r.eid,'অ্যাডাপটিভ সেট',r.qs)}catch(e){toast(e.message)}},
  async join(id){const b=DB.batches.find(x=>String(x.id)===String(id));
    if(b.fee>0)return sheet(`<b style="font-size:20px">পেমেন্ট — ৳${bn(b.fee)}</b><div class="mut" style="line-height:1.6">টাকা পাঠিয়ে নিচের তথ্য দাও। অ্যাডমিন যাচাই করলে ব্যাচ চালু হবে।</div><div class="chips">${['bKash','Nagad','Rocket'].map(m=>`<button class="fc" data-act="setPm" data-arg="${m}">${m}</button>`).join('')}</div><input class="in" id="pm" placeholder="পেমেন্ট মাধ্যম (যেমন bKash)" style="background:#F1F0FB;color:#14143A;border-color:#E4E2F7"><input class="in" id="pn" type="tel" placeholder="যে নম্বর থেকে পাঠিয়েছো" style="background:#F1F0FB;color:#14143A;border-color:#E4E2F7"><input class="in" id="pt" placeholder="Transaction ID" style="background:#F1F0FB;color:#14143A;border-color:#E4E2F7"><button class="btn b-i" data-act="pay" data-arg="${id}">পেমেন্ট জমা দাও</button>`);
    try{const r=await API.join(id);await loadAll();toast(r.message||'ব্যাচে যোগ দেওয়া হয়েছে ✓');draw()}catch(e){toast(e.message)}},
  setPm(m,el){$('#pm').value=m;document.querySelectorAll('.sheet .fc').forEach(x=>x.classList.remove('on'));el.classList.add('on')},
  async pay(id){const method=$('#pm').value.trim(),sender_number=$('#pn').value.trim(),transaction_id=$('#pt').value.trim();if(!method||!sender_number||!transaction_id)return toast('পেমেন্ট মাধ্যম, নম্বর ও Transaction ID দাও');
    try{const r=await API.join(id,{method,sender_number,transaction_id});closeSheet();await loadAll();toast(r.message||'পেমেন্ট জমা হয়েছে, যাচাই চলছে');draw()}catch(e){toast(e.message)}},
  pickCam(){$('#fcam').click()},pickGal(){$('#fgal').click()},
  async sendOmr(id){toast('আপলোড হচ্ছে…');try{const r=await API.omrUpload(id,omrFile);omrFile=null;await loadAll();toast(r.message||'শিট জমা হয়েছে ✓');replaceWith('omr')}catch(e){toast(e.message)}},
  faceGo(arg){const [m,x]=arg.split(':');faceScan(m,x)},
  faceGallery(){$('#ffile').click()},
  faceLeave(){sheet(`<b style="font-size:20px">পার্সোনাল কেয়ার ছেড়ে দেবে?</b><div class="mut">তোমার ছবি সার্ভার থেকে মুছে যাবে।</div><button class="btn b-i" data-act="closeSheet">না, থাকবো</button><button class="btn b-l" data-act="doLeave">ছেড়ে দাও</button>`)},
  async doLeave(){try{await API.faceLeave();await loadAll();closeSheet();toast('পার্সোনাল কেয়ার ছেড়ে দেওয়া হয়েছে');draw()}catch(e){toast(e.message)}}
};
document.addEventListener('click',e=>{
  if(e.target.classList&&e.target.classList.contains('mask'))return closeSheet();
  const t=e.target.closest('[data-go],[data-act],[data-tab]');if(!t||t.disabled)return;
  if(t.dataset.tab){hist=[];cur=t.dataset.tab;draw();return}
  if(t.dataset.act){const f=A[t.dataset.act];if(f)f(t.dataset.arg,t);return}
  if(t.dataset.go)go(t.dataset.go,t.dataset.rep?true:undefined);
});
draw();
})();
