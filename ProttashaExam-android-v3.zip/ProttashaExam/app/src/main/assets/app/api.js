/* API layer: live server (default) or DEMO. Every call is logged in window.PA_LOG for the diagnostics screen. */
(()=>{
const C=window.PA_CONFIG,D=window.PA_DATA,LOG=window.PA_LOG=[];
const wait=(v,ms=350)=>new Promise(r=>setTimeout(()=>r(v),ms));
const fail=m=>new Promise((_,j)=>setTimeout(()=>j(new Error(m)),350));
let token=null;const pend={};
window.__nativeCb=(id,code,b64)=>{const p=pend[id];if(!p)return;delete pend[id];let t='';try{t=decodeURIComponent(escape(atob(b64)))}catch(e){}p({code,txt:t})};
const b64=u=>{let s='';for(let i=0;i<u.length;i+=8192)s+=String.fromCharCode.apply(null,u.subarray(i,i+8192));return btoa(s)};
async function raw(method,url,body,form){
  const h={Accept:'application/json'};if(token)h.Authorization='Bearer '+token;let pl=null;
  if(form){h['Content-Type']='multipart/form-data; boundary='+body.boundary;pl=body.bytes}
  else if(body){h['Content-Type']='application/json';pl=new TextEncoder().encode(JSON.stringify(body))}
  let code=0,txt='';
  try{
    if(window.Native&&window.Native.request){const r=await new Promise(res=>{const id=Math.random().toString(36).slice(2);pend[id]=res;window.Native.request(id,method,url,JSON.stringify(h),pl?b64(pl):'')});code=r.code;txt=r.txt}
    else{const r=await fetch(url,{method,headers:h,body:pl});code=r.status;txt=await r.text()}
  }catch(e){txt=String(e)}
  let json=null;try{json=JSON.parse(txt)}catch(e){}
  LOG.push({m:method,u:url.replace(C.BASE,''),c:code,t:txt.slice(0,400)});if(LOG.length>40)LOG.shift();
  return {code,json,txt};
}
const errMsg=r=>(r.json&&(r.json.message||r.json.error||r.json.msg))||(r.code?('সার্ভার ত্রুটি ('+r.code+')'):'ইন্টারনেট সংযোগ নেই');
/* try each path until one succeeds (non-404) */
async function call(key,{id,body,form,query}={}){
  const [m,paths]=C.ROUTES[key];let last=null;
  for(const p of paths){
    const r=await raw(m,C.BASE+p.replace('{id}',id==null?'':id)+(query||''),body,form);
    if(r.code>=200&&r.code<300)return r.json==null?{}:r.json;
    last=(last&&last.code!==404&&r.code===404)?last:r;
    if(r.code!==404&&r.code!==405)break;
  }
  throw new Error(errMsg(last));
}
const un=r=>r&&typeof r==='object'&&!Array.isArray(r)&&r.data&&typeof r.data==='object'&&!Array.isArray(r.data)?Object.assign({},r,r.data):r;
const arr=(r,...ks)=>{if(Array.isArray(r))return r;if(!r||typeof r!=='object')return [];for(const k of [...ks,'data','items','results','rows']){const v=r[k];if(Array.isArray(v))return v;if(v&&typeof v==='object')for(const k2 of ks)if(Array.isArray(v[k2]))return v[k2]}return []};
const pick=(o,...ks)=>{for(const k of ks)if(o&&o[k]!==undefined&&o[k]!==null&&o[k]!=='')return o[k];return undefined};
const L='ABCD';
const toIdx=v=>{if(v==null||v==='')return undefined;if(typeof v==='number')return v>=1&&v<=4?v-1:undefined;const s=String(v).trim(),m=s.match(/^(?:option[_ ]?)?([a-dA-D])$/);if(m)return L.indexOf(m[1].toUpperCase());if(/^[1-4]$/.test(s))return +s-1;return undefined};
const opts=q=>{if(Array.isArray(q.options)&&q.options.length)return q.options.map(o=>o&&typeof o==='object'?(o.text||o.label||o.value||''):o);
  for(const ks of [['option_a','option_b','option_c','option_d'],['option1','option2','option3','option4'],['optionA','optionB','optionC','optionD']])if(ks.every(k=>q[k]!==undefined))return ks.map(k=>q[k]);return []};
const mapQ=q=>({id:pick(q,'id','question_id','_id'),s:pick(q,'topic_name','topic','subject')||'',t:pick(q,'question','question_text','text','title')||'',o:opts(q),a:toIdx(pick(q,'correct_option','correct_answer','answer','correct')),y:toIdx(pick(q,'selected_option','selected','your_answer')),x:pick(q,'explanation','ai_explanation')||''});
const mapExam=e=>{const now=Date.now(),st=Date.parse(pick(e,'start_time','starts_at','start_date','start_at')||''),en=Date.parse(pick(e,'end_time','ends_at','end_date','end_at')||''),sv=String(pick(e,'status')||'').toLowerCase();let s='live';
  if(/upcoming|scheduled|soon/.test(sv)||(st&&st>now))s='upcoming';else if(/ended|closed|finish|complete|expired/.test(sv)||(en&&en<now))s='ended';
  return {id:pick(e,'id','exam_id','_id'),title:pick(e,'title','name','exam_name')||'পরীক্ষা',subject:pick(e,'topic_name','subject','batch_name')||'',time:+pick(e,'duration_minutes','duration','time_limit','time')||30,status:s,when:st?new Date(st).toLocaleDateString('bn-BD',{weekday:'long'}):'',n:pick(e,'total_questions','question_count','questions_count'),attempted:!!pick(e,'attempted','submitted','already_attempted','is_submitted','result_id'),k:'i'}};
const mapResult=r=>{r=un(r);const tot=+pick(r,'total_questions','total')||0,c=pick(r,'correct_count','correct');return {rid:pick(r,'result_id','id'),score:pick(r,'score','marks'),max:pick(r,'max_marks','total_marks'),correct:c===undefined?undefined:+c,wrong:pick(r,'wrong_count','incorrect_count','wrong'),skipped:pick(r,'skipped_count','unanswered','skipped'),total:tot,rank:pick(r,'rank'),review:arr(r,'review','questions','answers').map(mapQ)}};
async function multipart(fields,files){
  const b='----pa'+Date.now(),e=new TextEncoder(),parts=[];
  for(const k in fields)parts.push(e.encode(`--${b}\r\nContent-Disposition: form-data; name="${k}"\r\n\r\n${fields[k]}\r\n`));
  for(const f of files){parts.push(e.encode(`--${b}\r\nContent-Disposition: form-data; name="${f.name}"; filename="${f.file.name||'photo.jpg'}"\r\nContent-Type: ${f.file.type||'image/jpeg'}\r\n\r\n`));parts.push(new Uint8Array(await f.file.arrayBuffer()));parts.push(e.encode('\r\n'))}
  parts.push(e.encode(`--${b}--\r\n`));const len=parts.reduce((a,p)=>a+p.length,0),bytes=new Uint8Array(len);let o=0;parts.forEach(p=>{bytes.set(p,o);o+=p.length});return {boundary:b,bytes};
}
const auth=r=>{r=un(r);const t=pick(r,'token','access_token','accessToken','jwt');if(!t)throw new Error('টোকেন পাওয়া যায়নি');token=t;const u=r.user||{};return {token:t,user:{name:pick(u,'name','full_name')||pick(r,'name')||'শিক্ষার্থী',email:pick(u,'email')||pick(r,'email')||'',id:pick(u,'id','_id')}}};
const emailOk=e=>/^\S+@\S+\.\S+$/.test(e);
window.PA_API={
  setToken(t){token=t},
  login(email,pass){if(C.DEMO)return !emailOk(email)||pass.length<4?fail('সঠিক ইমেইল ও পাসওয়ার্ড দাও'):wait({token:'demo',user:{name:'শিক্ষার্থী',email}});
    return call('login',{body:{email,password:pass}}).then(auth)},
  register(name,email,pass){if(C.DEMO)return !name||!emailOk(email)||pass.length<4?fail('সব ঘর পূরণ করো (পাসওয়ার্ড কমপক্ষে ৪ অক্ষর)'):wait({token:'demo',user:{name,email}});
    return call('register',{body:{name,email,password:pass}}).then(r=>{try{return auth(r)}catch(e){return call('login',{body:{email,password:pass}}).then(auth)}})},
  exams(){return C.DEMO?wait(D.exams,200):call('exams').then(r=>arr(r,'exams').map(mapExam))},
  async start(id){if(C.DEMO)return wait({qs:D.questions});const r=un(await call('start',{id,body:{}})),qs=arr(r,'questions').map(mapQ);if(!qs.length)throw new Error('এই পরীক্ষায় কোনো প্রশ্ন পাওয়া যায়নি');const d=+pick(r,'duration_minutes','duration','remaining_minutes')||0,sec=+pick(r,'remaining_seconds','seconds_left')||0;return {qs,time:d,sec}},
  async submit(id,qs,ans){if(C.DEMO)return wait(null,300);
    const answers=qs.map((q,i)=>ans[i]===undefined?null:{question_id:q.id,selected_option:L[ans[i]]}).filter(Boolean);
    const r=mapResult(await call('submit',{id,body:{answers}}));
    if(r.rid&&!r.review.length){try{r.review=mapResult(await call('review',{id:r.rid})).review}catch(e){}}
    if(r.rid&&r.correct===undefined){try{Object.assign(r,mapResult(await call('result',{id:r.rid})),{review:r.review})}catch(e){}}
    return r},
  async practice(){if(C.DEMO)return wait({qs:D.questions});const r=un(await call('practice',{body:{}}));const qs=arr(r,'questions').map(mapQ);if(!qs.length)throw new Error('প্র্যাকটিসের জন্য প্রশ্ন পাওয়া যায়নি (আগে ব্যাচের পরীক্ষা শেষ হতে হবে)');return {qs}},
  async adaptive(){if(C.DEMO)return null;const r=un(await call('adaptive',{body:{}}));const qs=arr(r,'questions').map(mapQ);if(!qs.length)throw new Error('এখনও কোনো ভুল প্রশ্ন নেই — আগে একটি পরীক্ষা দাও');return {qs}},
  practiceHist(){return C.DEMO?wait([]):call('practiceHist').then(r=>arr(r,'exams','history').map(x=>({title:pick(x,'title','name')||'প্র্যাকটিস',score:pick(x,'score','marks'),total:pick(x,'total_questions','total'),date:pick(x,'created_at','date')||''})))},
  leaderboard(){return C.DEMO?wait(D.board,200):call('leaderboard').then(r=>arr(r,'leaderboard','students').map(i=>({n:pick(i,'name','student_name')||'—',s:Math.round(+pick(i,'avg_score','average','score')||0),t:pick(i,'total_attempts'),me:!!pick(i,'is_me','me')})))},
  performance(){return C.DEMO?wait([],100):call('performance').then(r=>arr(r,'exams','performance','items').map(x=>({title:pick(x,'exam_title','title','name')||'পরীক্ষা',score:pick(x,'score','marks','percentage'),max:pick(x,'max_marks','total_marks')})))},
  async home(){if(C.DEMO)return {batches:D.batches};const r=un(await call('home'));return {batches:arr(r,'batches').map(b=>({id:pick(b,'id','_id'),title:pick(b,'name','title')||'ব্যাচ',desc:pick(b,'description','desc')||'',exams:+pick(b,'exam_count','published_exams','exams_count','topic_count')||0,days:+pick(b,'days','duration_days')||0,fee:+pick(b,'price','fee')||0,joined:!!pick(b,'joined','is_member','is_joined','enrolled'),pending:/pend/i.test(String(pick(b,'membership_status','status','join_status')||''))}))}},
  batches(){return this.home().then(h=>h.batches)},
  enroll(id,pay){return C.DEMO?wait({ok:true},400):call('join',{id,body:pay?{transaction_id:pay.trx,payment_method:pay.method}:{}})},
  explain(q){if(q.x)return wait(q.x,300);return C.DEMO?wait('এই প্রশ্নের ব্যাখ্যা পাওয়া যায়নি।',500):call('explain',{body:{question_id:q.id,question:q.t,options:q.o}}).then(r=>{r=un(r);return pick(r,'explanation','text','answer','content')||'ব্যাখ্যা পাওয়া যায়নি'})},
  async omr(file,examId){if(C.DEMO)return wait({ok:true},700);let last;for(const f of ['photo','file','image','sheet']){try{return await call('omrUpload',{id:examId||'',form:true,body:await multipart({},[{name:f,file}])})}catch(e){last=e}}throw last},
  omrExams(){return C.DEMO?wait([{id:'o1',title:'ওএমআর মডেল টেস্ট'}],100):call('omrBatches').then(r=>{const out=[];arr(r,'batches').forEach(b=>{const ex=b.exams||b.omr_exams;if(Array.isArray(ex))ex.forEach(e=>out.push({id:pick(e,'id','exam_id'),title:pick(e,'title','name')||'OMR পরীক্ষা'}));else if(b.id)out.push({id:b.id,title:pick(b,'name','title')||'OMR'})});return out})},
  faceMe(){return C.DEMO?wait({enrolled:false},200):call('faceMe')},
  async faceEnroll(blob){if(C.DEMO)return wait({ok:true},700);return call('faceEnroll',{form:true,body:await multipart({},[{name:'photo',file:blob}])})},
  async attendance(blob){if(C.DEMO)return wait({ok:true},700);return call('attendance',{form:true,body:await multipart({},[{name:'photo',file:blob}])})},
  async diag(){const out=[];for(const k of ['home','exams','leaderboard','performance','faceMe','omrBatches','practiceHist']){const [m,ps]=C.ROUTES[k];const r=await raw(m,C.BASE+ps[0]);out.push({k,u:ps[0],c:r.code,t:r.txt.slice(0,160)})}return out},
  mapResult
};
})();
