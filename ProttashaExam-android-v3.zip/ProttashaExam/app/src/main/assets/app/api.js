/* API layer – written against the real backend (routes/*.js of prottashaacademy.com). Nothing is stored on the phone. */
(()=>{
const C=window.PA_CONFIG,LOG=window.PA_LOG=[];
let token=null;const pend={};
window.__nativeCb=(id,code,b64)=>{const p=pend[id];if(!p)return;delete pend[id];let t='';try{t=decodeURIComponent(escape(atob(b64)))}catch(e){}p({code,txt:t})};
const b64=u=>{let s='';for(let i=0;i<u.length;i+=8192)s+=String.fromCharCode.apply(null,u.subarray(i,i+8192));return btoa(s)};
async function raw(method,path,o={}){
  const h={Accept:'application/json'};if(token)h.Authorization='Bearer '+token;let pl=null;
  if(o.bytes){h['Content-Type']=o.type||'application/octet-stream';pl=o.bytes}
  else if(o.json!==undefined){h['Content-Type']='application/json';pl=new TextEncoder().encode(JSON.stringify(o.json))}
  const url=C.BASE+path;let code=0,txt='';
  try{
    if(window.Native&&window.Native.request){const r=await new Promise(res=>{const id=Math.random().toString(36).slice(2);pend[id]=res;window.Native.request(id,method,url,JSON.stringify(h),pl?b64(pl):'')});code=r.code;txt=r.txt}
    else{const r=await fetch(url,{method,headers:h,body:pl});code=r.status;txt=await r.text()}
  }catch(e){txt=String(e)}
  let data=null;try{data=JSON.parse(txt)}catch(e){}
  LOG.push({m:method,u:path,c:code,t:txt.slice(0,300)});if(LOG.length>40)LOG.shift();
  return {code,data,txt};
}
async function call(method,path,o){
  const r=await raw(method,path,o);
  if(r.code>=200&&r.code<300)return r.data==null?{}:r.data;
  const msg=(r.data&&r.data.error)||(r.code?('সার্ভার ত্রুটি ('+r.code+')'):'ইন্টারনেট সংযোগ নেই');
  if(token&&(r.code===401||(r.code===403&&/session/i.test(msg)))){token=null;if(window.__authLost)window.__authLost(msg)}
  const e=new Error(msg);e.code=r.data&&r.data.code;e.status=r.code;throw e;
}
const L='abcd',pick=(o,...ks)=>{for(const k of ks)if(o&&o[k]!==undefined&&o[k]!==null&&o[k]!=='')return o[k]};
const toIdx=v=>{if(v==null||v==='')return undefined;if(typeof v==='number')return v>=1&&v<=4?v-1:undefined;const i=L.indexOf(String(v).trim().toLowerCase());return i>=0?i:(/^[1-4]$/.test(String(v))?+v-1:undefined)};
const ms=s=>{if(s==null||s==='')return null;if(typeof s==='number')return s;const t=String(s),z=/[zZ]$|[+-]\d\d:?\d\d$/.test(t)?t:t.replace(' ','T')+'Z',v=Date.parse(z);return isNaN(v)?null:v};
const qOpts=q=>{const o=q.options;if(Array.isArray(o))return o;if(o&&typeof o==='object')return ['a','b','c','d'].map(k=>o[k]);
  for(const ks of [['option_a','option_b','option_c','option_d'],['option1','option2','option3','option4']])if(ks.every(k=>q[k]!==undefined))return ks.map(k=>q[k]);return []};
const mapQ=q=>({id:pick(q,'id','question_id'),s:pick(q,'topic_name')||'',t:pick(q,'question_text','question')||'',o:qOpts(q),a:toIdx(pick(q,'correct_answer')),y:toIdx(pick(q,'your_answer')),x:pick(q,'explanation')||''});
const mapReview=(rows,qs)=>(rows||[]).map(r=>{const b=(qs||[]).find(q=>String(q.id)===String(r.question_id))||{};return {id:r.question_id,s:b.s||'',t:r.question_text||b.t||'',o:r.options?qOpts(r):(b.o||[]),a:toIdx(r.correct_answer),y:toIdx(r.your_answer),x:r.explanation||''}});
const normResult=(r,qs)=>({hidden:!!r.result_hidden,msg:r.message||'',rid:r.result_id,percent:r.score,marks:r.marks,max:r.max_marks,correct:r.correct_count,wrong:r.wrong_count,skipped:r.skipped_count,total:r.total_questions,rank:r.rank,participants:r.participants,title:r.title,review:mapReview(r.results,qs),done:r.exams_completed,adaptiveReady:r.adaptive_exam_ready});
const mapExam=e=>({id:e.id,title:e.title||'পরীক্ষা',sec:+e.time_limit_seconds||0,time:Math.max(1,Math.round((+e.time_limit_seconds||0)/60)),n:+e.questions||0,state:e.state||'open',mode:e.mode||'online',choice:e.choice||null,hasOmr:!!e.has_omr,batch:e.batch_name||'',batchId:e.batch_id,price:+e.batch_price||0,endMs:e.end_ms,startMs:e.start_ms,remaining:e.remaining_seconds,result:e.result||null,hidden:!!e.result_hidden,note:e.result_note||'',omrSub:e.omr_submission||null});
const mapBatch=b=>({id:b.id,title:b.name,fee:+b.price||0,exams:+b.exams||0,state:b.state||'none',list:(b.exam_list||[]).map(x=>({id:x.id,title:x.title,mode:x.mode,qn:x.questions,done:!!x.done,sheet:!!x.has_sheet,sub:x.sub,end:x.end_time}))});
async function toJpeg(file,max=2200){
  const url=URL.createObjectURL(file);
  try{
    const img=await new Promise((res,rej)=>{const i=new Image();i.onload=()=>res(i);i.onerror=()=>rej(new Error('ছবি পড়া যায়নি — JPG বা PNG ছবি দাও'));i.src=url});
    let w=img.naturalWidth,h=img.naturalHeight;const k=Math.min(1,max/Math.max(w,h));w=Math.round(w*k);h=Math.round(h*k);
    const c=document.createElement('canvas');c.width=w;c.height=h;const x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,w,h);x.drawImage(img,0,0,w,h);
    const blob=await new Promise(r=>c.toBlob(r,'image/jpeg',.9));return new Uint8Array(await blob.arrayBuffer());
  }finally{URL.revokeObjectURL(url)}
}
const authOk=r=>{if(!r.token)throw new Error('টোকেন পাওয়া যায়নি');token=r.token;return {token:r.token,user:r.user||{}}};
window.PA_API={
  setToken(t){token=t},
  login:(email,password)=>call('POST','/auth/login',{json:{email,password}}).then(authOk),
  register:(name,email,password)=>call('POST','/auth/register',{json:{name,email,password}}).then(authOk),
  exams:()=>call('GET','/online/exams').then(r=>(r.exams||[]).map(mapExam)),
  async start(id){const r=await call('POST','/online/exams/'+id+'/start',{json:{}});return {qs:(r.questions||[]).map(mapQ),sec:r.remaining_seconds,title:r.title}},
  choose:(id,mode)=>call('POST','/online/exams/'+id+'/choose',{json:{mode}}),
  paper:id=>call('GET','/online/exams/'+id+'/paper').then(r=>({title:r.title,sec:r.time_limit_seconds,qs:(r.questions||[]).map(q=>({no:q.no,t:q.question,o:qOpts(q)}))})),
  async submitExam(id,qs,ans){const answers=qs.map((q,i)=>({question_id:q.id,selected_option:ans[i]!==undefined?L[ans[i]]:null,time_taken_seconds:0}));
    return normResult(await call('POST','/online/exams/'+id+'/submit',{json:{answers}}),qs)},
  review:rid=>call('GET','/online/results/'+rid+'/review').then(r=>normResult(r,[])),
  pexams:()=>call('GET','/exam/practice-exams').then(r=>(r.exams||[]).map(e=>({id:e.id,title:e.title,batch:e.batch_name,n:e.questions,done:!!e.participated,open:!!e.practice_open}))),
  async generate(opt){const r=await call('POST','/exam/generate',{json:opt||{count:10}});return {eid:r.exam_id,qs:(r.questions||[]).map(mapQ),msg:r.message}},
  async adaptive(){const r=await call('POST','/exam/generate-adaptive',{json:{}});return {eid:r.exam_id,qs:(r.questions||[]).map(mapQ),msg:r.message}},
  async submitPractice(eid,qs,ans){const answers=qs.map((q,i)=>({question_id:q.id,selected_option:ans[i]!==undefined?L[ans[i]]:null,time_taken_seconds:0}));
    return normResult(await call('POST','/exam/'+eid+'/submit',{json:{answers}}),qs)},
  explain:(qid,letter)=>call('POST','/exam/ai-explain',{json:{question_id:Number(qid),student_answer:letter||null}}).then(r=>r.explanation||'ব্যাখ্যা পাওয়া যায়নি'),
  performance:()=>call('GET','/exam/performance').then(r=>({done:+r.exams_completed||0,need:+r.exams_needed||0,ready:!!r.adaptive_ready,topics:(r.topic_performance||[]).map(t=>({n:t.topic_name,b:t.batch_name,p:Math.round((+t.accuracy||0)*100),lv:t.level}))})),
  history:()=>call('GET','/exam/history').then(r=>(r.exams||[]).map(x=>({id:x.id,type:x.exam_type,status:x.status,score:x.score,ms:ms(x.completed_at||x.created_at)}))),
  leaderboard:()=>call('GET','/exam/leaderboard').then(r=>(r.leaderboard||[]).map(x=>({id:x.student_id,n:x.name,s:Math.round(+x.avg_score||0),t:x.exams_completed}))),
  batches:()=>call('GET','/omr/batches').then(r=>(r.batches||[]).map(mapBatch)),
  join:(id,pay)=>call('POST','/omr/batches/'+id+'/join',{json:pay||{}}),
  omrOverview:()=>call('GET','/omr/overview').then(r=>(r.exams||[]).map(x=>({id:x.exam_id,title:x.title,end:x.end_time,n:x.questions,online:!!x.took_online,mode:x.mode,choice:x.choice,started:!!x.started,needsChoice:!!x.needs_choice,canPaper:!!x.can_view_paper,canSubmit:!!x.can_submit,closed:!!x.closed,sub:x.submission,hidden:!!x.result_hidden,note:x.result_note,result:x.result}))),
  async omrUpload(id,file){const bytes=await toJpeg(file);return call('POST','/omr/exams/'+id+'/submission',{bytes,type:'image/jpeg'})},
  omrReview:rid=>call('GET','/omr/results/'+rid+'/review').then(r=>(r.answers||[]).map(a=>({id:a.question,s:'',t:a.question,o:[a.option1,a.option2,a.option3,a.option4],a:toIdx(a.correct_option),y:toIdx(a.selected_option),x:''}))),
  faceMe:()=>call('GET','/face/me').then(r=>({enrolled:!!r.enrolled,status:r.status,photo:r.photo,required:!!r.required_for_exams,recent:(r.recent||[]).map(x=>({kind:x.kind,title:x.title,ms:ms(x.marked_at)}))})),
  faceEnroll:(descriptor,photo,uploaded)=>call('POST','/face/enroll',{json:{descriptor,photo,consent:true,uploaded:!!uploaded}}),
  faceLeave:()=>call('DELETE','/face/me'),
  faceVerify:(descriptor,examId)=>call('POST','/face/verify',{json:{descriptor,exam_id:examId||null}}),
  async diag(){const out=[];for(const p of ['/public/home','/online/exams','/omr/overview','/omr/batches','/exam/performance','/exam/history','/exam/leaderboard','/exam/practice-exams','/face/me']){const r=await raw('GET',p);out.push({u:p,c:r.code,t:r.txt.slice(0,140)})}return out}
};
})();
