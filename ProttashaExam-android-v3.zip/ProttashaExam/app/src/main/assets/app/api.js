/* API layer: live server (default) or DEMO. Every call is logged in window.PA_LOG for the diagnostics screen. */
(()=>{
const C=window.PA_CONFIG,D=window.PA_DATA,LOG=window.PA_LOG=[];
const wait=(v,ms=350)=>new Promise(r=>setTimeout(()=>r(v),ms));
const fail=m=>new Promise((_,j)=>setTimeout(()=>j(new Error(m)),350));
let token=null,uid=null;const pend={};
window.__nativeCb=(id,code,b64)=>{const p=pend[id];if(!p)return;delete pend[id];let t='';try{t=decodeURIComponent(escape(atob(b64)))}catch(e){}p({code,txt:t})};
const b64=u=>{let s='';for(let i=0;i<u.length;i+=8192)s+=String.fromCharCode.apply(null,u.subarray(i,i+8192));return btoa(s)};
async function raw(method,url,body,form){
  const h={Accept:'application/json'};if(token)h.Authorization='Bearer '+token;let pl=null;
  if(form){h['Content-Type']='multipart/form-data; boundary='+body.boundary;pl=body.bytes}
  else if(body){h['Content-Type']='application/json';pl=new TextEncoder().encode(JSON.stringify(body))}
  let code=0,txt='';
  try{
    if(window.Native&&window.Native.request){const r=await new Promise(res=>{const id=Math.random().toString(36).slice(2);pend[id]=res;window.Native.request(id,method,url,JSON.stringify(h),pl?b64(pl):'')});code=r.code;txt=r.txt}
    else{const r=await fetch(url,{method,headers:h,body:pl});code=r.status;txt=await r.text()}
  }catch(e){txt=String(e)}
  let json=null;try{json=JSON.parse(txt)}catch(e){}
  LOG.push({m:method,u:url.replace(C.BASE,''),c:code,t:txt.slice(0,400)});if(LOG.length>40)LOG.shift();
  return {code,json,txt};
}
const errMsg=r=>(r.json&&(r.json.message||r.json.error||r.json.msg))||(r.code?('সার্ভার ত্রুটি ('+r.code+')'):'ইন্টারনেট সংযোগ নেই');
/* try each path until one succeeds (non-404) */
async function call(key,{id,body,form,query}={}){
  const [m,paths]=C.ROUTES[key];let last=null;
  for(const p of paths){
    const r=await raw(m,C.BASE+p.replace('{id}',id==null?'':id)+(query||''),body,form);
    if(r.code>=200&&r.code<300)return r.json==null?{}:r.json;
    last=(last&&last.code!==404&&r.code===404)?last:r;
    if(r.code!==404&&r.code!==405)break;
  }
  throw new Error(errMsg(last));
}
const un=r=>r&&typeof r==='object'&&!Array.isArray(r)&&r.data&&typeof r.data==='object'&&!Array.isArray(r.data)?Object.assign({},r,r.data):r;
const arr=(r,...ks)=>{if(Array.isArray(r))return r;if(!r||typeof r!=='object')return [];for(const k of [...ks,'data','items','results','rows']){const v=r[k];if(Array.isArray(v))return v;if(v&&typeof v==='object')for(const k2 of ks)if(Array.isArray(v[k2]))return v[k2]}return []};
const pick=(o,...ks)=>{for(const k of ks)if(o&&o[k]!==undefined&&o[k]!==null&&o[k]!=='')return o[k];return undefined};
const L='ABCD';
const toIdx=v=>{if(v==null||v==='')return undefined;if(typeof v==='number')return v>=1&&v<=4?v-1:undefined;const s=String(v).trim(),m=s.match(/^(?:option[_ ]?)?([a-dA-D])$/);if(m)return L.indexOf(m[1].toUpperCase());if(/^[1-4]$/.test(s))return +s-1;return undefined};
const opts=q=>{if(Array.isArray(q.options)&&q.options.length)return q.options.map(o=>o&&typeof o==='object'?(o.text||o.label||o.value||''):o);
  for(const ks of [['option_a','option_b','option_c','option_d'],['option1','option2','option3','option4'],['optionA','optionB','optionC','optionD']])if(ks.every(k=>q[k]!==undefined))return ks.map(k=>q[k]);return []};
const mapQ=q=>({id:pick(q,'id','question_id','_id'),s:pick(q,'topic_name','topic','subject')||'',t:pick(q,'question','question_text','q','q_text','text','title','content')||'',o:opts(q),a:toIdx(pick(q,'correct_option','correct_answer','answer','correct')),y:toIdx(pick(q,'selected_option','selected','your_answer')),x:pick(q,'explanation','ai_explanation')||''});
const mapExam=e=>{const now=Date.now(),st=Date.parse(pick(e,'start_time','starts_at','start_date','start_at')||''),en=pick(e,'end_ms')?+e.end_ms:Date.parse(pick(e,'end_time','ends_at','end_date','end_at')||''),sv=String(pick(e,'status')||'').toLowerCase();let s='live';
  if(/upcoming|scheduled|soon/.test(sv)||(st&&st>now))s='upcoming';else if(/ended|closed|finish|complete|expired/.test(sv)||(en&&en<now))s='ended';
  const sec=+pick(e,'time_limit_seconds')||(+pick(e,'duration_minutes','duration','time_limit','time')||30)*60,qn=pick(e,'total_questions','question_count','questions_count','questions'),rid=pick(e,'result_id','attempt_id','my_result_id');
  return {id:pick(e,'id','exam_id','_id'),title:pick(e,'title','name','exam_name')||'পরীক্ষা',subject:pick(e,'batch_name','topic_name','subject')||'',time:Math.max(1,Math.ceil(sec/60)),sec,status:s,when:st?new Date(st).toLocaleDateString('bn-BD',{weekday:'long'}):'',n:typeof qn==='number'?qn:(Array.isArray(qn)?qn.length:(+qn||undefined)),attempted:!!pick(e,'participated','attempted','submitted','already_attempted','is_attempted','is_submitted')||!!rid,rid,k:'i'}};
const mapResult=r=>{r=un(r);if(r.result&&typeof r.result==='object'&&!Array.isArray(r.result))r=Object.assign({},r,r.result);const tot=+pick(r,'total_questions','total')||0,c=pick(r,'correct_count','correct');return {rid:pick(r,'result_id','id'),score:pick(r,'score','marks'),max:pick(r,'max_marks','total_marks'),correct:c===undefined?undefined:+c,wrong:pick(r,'wrong_count','incorrect_count','wrong'),skipped:pick(r,'skipped_count','unanswered','skipped'),total:tot,rank:pick(r,'rank'),review:arr(r,'review','questions','answers').map(mapQ)}};
async function multipart(fields,files){
  const b='----pa'+Date.now(),e=new TextEncoder(),parts=[];
  for(const k in fields)parts.push(e.encode(`--${b}\r\nContent-Disposition: form-data; name="${k}"\r\n\r\n${fields[k]}\r\n`));
  for(const f of files){parts.push(e.encode(`--${b}\r\nContent-Disposition: form-data; name="${f.name}"; filename="${f.file.name||'photo.jpg'}"\r\nContent-Type: ${f.file.type||'image/jpeg'}\r\n\r\n`));parts.push(new Uint8Array(await f.file.arrayBuffer()));parts.push(e.encode('\r\n'))}
  parts.push(e.encode(`--${b}--\r\n`));const len=parts.reduce((a,p)=>a+p.length,0),bytes=new Uint8Array(len);let o=0;parts.forEach(p=>{bytes.set(p,o);o+=p.length});return {boundary:b,bytes};
}
const jwt=t=>{try{return JSON.parse(decodeURIComponent(escape(atob(t.split('.')[1].replace(/-/g,'+').replace(/_/g,'/')))))}catch(e){return {}}};
const auth=r=>{r=un(r);const t=pick(r,'token','access_token','accessToken','jwt');if(!t)throw new Error('টোকেন পাওয়া যায়নি');token=t;const u=r.user||{},j=jwt(t),user={name:pick(u,'name','full_name')||pick(r,'name')||j.name||'শিক্ষার্থী',email:pick(u,'email')||pick(r,'email')||j.email||'',id:pick(u,'id','_id')||j.id};uid=user.id;return {token:t,user}};
const bstat=b=>{const m=String(pick(b,'membership_status','join_status','my_status','payment_status','member_status')||'').toLowerCase(),g=String(pick(b,'status')||'').toLowerCase();return {joined:!!pick(b,'joined','is_joined','is_member','enrolled','is_enrolled')||/approved|active|joined|member|paid/.test(m),pending:/pend|wait|review|submitted/.test(m)||/pend/.test(g)}};
const emailOk=e=>/^\S+@\S+\.\S+$/.test(e);
async function toJpeg(file,max=1800){
  const url=URL.createObjectURL(file);
  try{
    const img=await new Promise((res,rej)=>{const i=new Image();i.onload=()=>res(i);i.onerror=()=>rej(new Error('ছবি পড়া যায়নি — JPG বা PNG ছবি দাও'));i.src=url});
    let w=img.naturalWidth,h=img.naturalHeight;const k=Math.min(1,max/Math.max(w,h));w=Math.round(w*k);h=Math.round(h*k);
    const c=document.createElement('canvas');c.width=w;c.height=h;const x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,w,h);x.drawImage(img,0,0,w,h);
    const blob=await new Promise(r=>c.toBlob(r,'image/jpeg',.88));
    return new File([blob],'omr.jpg',{type:'image/jpeg'});
  }finally{URL.revokeObjectURL(url)}
}
window.PA_API={
  setToken(t){token=t},
  login(email,pass){if(C.DEMO)return !emailOk(email)||pass.length<4?fail('সঠিক ইমেইল ও পাসওয়ার্ড দাও'):wait({token:'demo',user:{name:'শিক্ষার্থী',email}});
    return call('login',{body:{email,password:pass}}).then(auth)},
  register(name,email,pass){if(C.DEMO)return !name||!emailOk(email)||pass.length<4?fail('সব ঘর পূরণ করো (পাসওয়ার্ড কমপক্ষে ৪ অক্ষর)'):wait({token:'demo',user:{name,email}});
    return call('register',{body:{name,email,password:pass}}).then(r=>{try{return auth(r)}catch(e){return call('login',{body:{email,password:pass}}).then(auth)}})},
  exams(){return C.DEMO?wait(D.exams,200):call('exams').then(r=>arr(r,'exams').map(mapExam))},
  async start(id){if(C.DEMO)return wait({qs:D.questions});const r=un(await call('start',{id,body:{}})),qs=arr(r,'questions').map(mapQ);if(!qs.length)throw new Error('এই পরীক্ষায় কোনো প্রশ্ন পাওয়া যায়নি');const d=+pick(r,'duration_minutes','duration','remaining_minutes')||0,sec=+pick(r,'remaining_seconds','seconds_left','time_limit_seconds')||0;return {qs,time:d,sec}},
  async submit(id,qs,ans,practice){if(C.DEMO)return wait(null,300);
    const L2=['A','B','C','D'],given=qs.map((q,i)=>({q,i})).filter(x=>ans[x.i]!==undefined);
    const bodies=[{answers:given.map(x=>({question_id:x.q.id,selected_option:L2[ans[x.i]]}))},
      {answers:Object.fromEntries(given.map(x=>[x.q.id,L2[ans[x.i]]]))},
      {answers:given.map(x=>({question_id:x.q.id,selected_option:ans[x.i]+1}))}];
    let r=null,last;
    for(const body of bodies){try{r=mapResult(await call(practice?'submitPractice':'submit',{id,body}));break}catch(e){last=e}}
    if(!r)throw last;
    if(practice){try{const rv=mapResult(await call('reviewPractice',{id}));if(rv.review.length)r.review=rv.review;if(r.correct===undefined&&rv.correct!==undefined){r.correct=rv.correct;r.total=rv.total;r.score=rv.score;r.wrong=rv.wrong;r.skipped=rv.skipped}}catch(e){}}
    else if(r.rid&&!r.review.length){try{r.review=mapResult(await call('review',{id:r.rid})).review}catch(e){}}
    return r},
  async practice(){if(C.DEMO)return wait({qs:D.questions});const r=un(await call('practice',{body:{}}));const qs=arr(r,'questions').map(mapQ);if(!qs.length)throw new Error('প্র্যাকটিসের জন্য প্রশ্ন পাওয়া যায়নি (আগে ব্যাচের পরীক্ষা শেষ হতে হবে)');return {qs,eid:pick(r,'exam_id','id')}},
  async adaptive(){if(C.DEMO)return null;const r=un(await call('adaptive',{body:{}}));const qs=arr(r,'questions').map(mapQ);if(!qs.length)throw new Error('এখনও কোনো ভুল প্রশ্ন নেই — আগে একটি পরীক্ষা দাও');return {qs,eid:pick(r,'exam_id','id')}},
  practiceHist(){return C.DEMO?wait([]):call('practiceHist').then(r=>arr(r,'exams','history').map(x=>({title:pick(x,'title','name')||'প্র্যাকটিস',score:pick(x,'score','marks'),total:pick(x,'total_questions','total'),date:pick(x,'created_at','date')||''})))},
  leaderboard(){return C.DEMO?wait(D.board,200):call('leaderboard').then(r=>arr(r,'leaderboard','students').map(i=>({n:pick(i,'name','student_name')||'—',s:Math.round(+pick(i,'avg_score','average','score')||0),t:pick(i,'exams_completed','total_attempts'),me:!!pick(i,'is_me','me')||(uid!=null&&String(pick(i,'student_id','id'))===String(uid))})))},
  async performance(){if(C.DEMO)return {done:0,need:5,ready:false,topics:[]};const r=un(await call('performance'));return {done:+pick(r,'exams_completed')||0,need:+pick(r,'exams_needed')||0,ready:!!r.adaptive_ready,topics:arr(r,'topic_performance','topics').map(x=>({n:pick(x,'topic','topic_name','name','subject')||'টপিক',p:Math.round(+pick(x,'accuracy','percentage','percent','score','avg_score')||0)}))}},
  async home(){if(C.DEMO)return {batches:D.batches};const r=un(await call('home'));return {batches:arr(r,'batches').map(b=>({id:pick(b,'id','_id'),title:pick(b,'name','title')||'ব্যাচ',desc:pick(b,'description','desc')||'',exams:+pick(b,'exam_count','published_exams','exams_count','topic_count')||0,days:+pick(b,'days','duration_days')||0,fee:+pick(b,'price','fee')||0,...bstat(b)}))}},
  async batches(){if(C.DEMO)return (await this.home()).batches;
    const [h,o]=await Promise.allSettled([this.home(),call('omrBatches')]);
    const hb=h.status==='fulfilled'?h.value.batches:[],ob=o.status==='fulfilled'?arr(o.value,'batches'):[];
    if(!ob.length)return hb;
    return ob.map(b=>{const id=pick(b,'id','_id'),x=hb.find(y=>String(y.id)===String(id))||{},s=String(pick(b,'state','status','membership_status')||'').toLowerCase(),list=Array.isArray(b.exam_list)?b.exam_list:[];
      return {id,title:pick(b,'name','title')||x.title||'ব্যাচ',desc:x.desc||'',exams:+pick(b,'exams','exam_count')||x.exams||list.length,days:x.days||0,fee:+pick(b,'price','fee')||0,joined:/approved|active|joined|member|paid|enrolled|accepted/.test(s),pending:/pend|wait|review|submitted|request/.test(s),state:s}})},
  enroll(id,pay){return C.DEMO?wait({ok:true},400):call('join',{id,body:pay?{transaction_id:pay.trx,payment_method:pay.method}:{}})},
  explain(q){if(q.x)return wait(q.x,300);return C.DEMO?wait('এই প্রশ্নের ব্যাখ্যা পাওয়া যায়নি।',500):call('explain',{body:{question_id:q.id,question:q.t,options:q.o}}).then(r=>{r=un(r);return pick(r,'explanation','text','answer','content')||'ব্যাখ্যা পাওয়া যায়নি'})},
  async omr(file,examId){if(C.DEMO)return wait({ok:true},700);const jpg=await toJpeg(file);let last;
    for(const f of ['photo','file','image','sheet','omr']){try{const r=un(await call('omrUpload',{id:examId||'',form:true,body:await multipart({},[{name:f,file:jpg}])}));const sc=pick(r,'score','marks','total_marks');return {msg:pick(r,'message')||('শিট জমা হয়েছে'+(sc!==undefined?' · স্কোর '+sc:''))}}catch(e){last=e}}throw last},
  async omrExams(){if(C.DEMO)return [{id:'o1',title:'ওএমআর মডেল টেস্ট'}];const r=await call('omrBatches');const out=[];arr(r,'batches').forEach(b=>{(Array.isArray(b.exam_list)?b.exam_list:[]).forEach(e=>out.push({id:pick(e,'id','exam_id'),title:pick(e,'title','name','exam_name')||'OMR পরীক্ষা'}))});return out},
  async history(){if(C.DEMO)return [];const r=await call('history');return arr(r,'exams','history','items').map(x=>({id:pick(x,'id','exam_id'),type:String(pick(x,'exam_type','type')||''),status:String(pick(x,'status')||''),score:pick(x,'score'),date:pick(x,'completed_at','created_at')||''}))},
  async practiceReview(id){return mapResult(await call('reviewPractice',{id}))},
  async faceMe(){if(C.DEMO)return {enrolled:false,records:[]};try{const r=un(await call('faceMe'));const f=r.face&&typeof r.face==='object'?r.face:r;return {status:pick(r,'status'),enrolled:!!pick(f,'photo','photo_url','image','image_url','face_photo','enrolled','is_enrolled','joined','active'),records:arr(r,'attendance','records','history','recent','logs').map(x=>({date:pick(x,'date','created_at','timestamp','marked_at','time','checked_at'),status:pick(x,'status'),kind:pick(x,'kind'),title:pick(x,'title')}))}}catch(e){return {enrolled:false,records:[],err:e.message}}},
  faceLeave(){return call('faceLeave')},
  async omrStatus(id){if(C.DEMO)return null;try{const r=un(await call('omrStatus',{id}));const s=pick(r,'status','state'),sc=pick(r,'score','marks','total_marks');return (s||sc!==undefined)?('অবস্থা: '+(s||'জমা হয়েছে')+(sc!==undefined?' · স্কোর: '+sc:'')):null}catch(e){return null}},
  async resultFull(rid){return mapResult(await call('review',{id:rid}))},
  async faceEnroll(blob){if(C.DEMO)return wait({ok:true},700);return call('faceEnroll',{form:true,body:await multipart({consent:'true',agree:'true',accepted:'true'},[{name:'photo',file:blob}])})},
  async attendance(blob){if(C.DEMO)return wait({ok:true},700);return call('attendance',{form:true,body:await multipart({},[{name:'photo',file:blob}])})},
  async diag(){const out=[];for(const k of Object.keys(C.ROUTES)){const [m,ps]=C.ROUTES[k];if(m!=='GET')continue;for(const p of ps){const r=await raw(m,C.BASE+p.replace('{id}','1'));out.push({k,u:p,c:r.code,t:r.txt.slice(0,140)})}}return out},
  mapResult
};
})();
